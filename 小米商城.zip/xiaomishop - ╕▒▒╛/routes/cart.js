const express = require("express")
const router = express.Router()
const pool = require("../pool")

router.get("/add", (req, res) => {
	var lid = req.query.lid;
	var count = req.query.count;
	var uid = req.session.uid;
	//console.log(uid, lid, count);
	pool.query(
		"select * from m_shoppingcart_item where uid=? and lid=?", [uid, lid],
		(err, result) => {
			if(err) throw err;
			if(result.length == 0) {
				pool.query(
					"insert into xz_shoppingcart_item values(null,?,?,?,0)", [uid, lid, count],
					(err, result) => {
						if(err) throw err;
						res.end();
					})
			}
			else {
				pool.query(
					"update m_shoppingcart_item set count=count+? where uid=? and lid=?", [count, uid, lid, ],
					(err, result) => {
						if(err) throw err;
						res.end();
					})
			}
		}
	)
})

module.exports = router;