window.onload = function() {
	new Vue({
		el: ".carrousel",
		data: {
			imgArr: [{
					src: "img/banner.jpg",
					id: "carrousel_img1"
				},
				{
					src: "img/banner2.jpg",
					id: "carrousel_img2"
				},
				{
					src: "img/banner3.jpg",
					id: "carrousel_img3"
				},
				{
					src: "img/banner4.jpg",
					id: "carrousel_img4"
				},
				{
					src: "img/banner5.jpg",
					id: "carrousel_img5"
				}
			],
			mark: 0
		},
		mounted() {
			this.play();
		},
		methods: {
			autoplay() {
				this.mark++;
				if(this.mark == this.imgArr.length)
					this.mark = 0;
			},
			play() {
				timer = setInterval(this.autoplay, 3000)
			},
			clearauto() {
				clearInterval(timer)
			},
			clickleft() {
				if(this.mark == 0) {
					this.mark = this.imgArr.length - 1;
				} else {
					this.mark--;
				}

			},
			clickright() {
				if(this.mark == this.imgArr.length - 1) {
					this.mark = 0;
				} else {
					this.mark++;
				}

			},
			setIndex(mark) {
				this.mark = mark;
			},
			mouseenter() {
				this.clearauto();
			},
			mouseleave() {
				this.play();
			}
		}
	});

	/*--------to top---------*/
//	$(window).scroll(function() {
//		var scrollValue = $(window).scrollTop();
//		scrollValue > 500 ? $('[class=totop]').fadeIn() : $('[class=totop]').fadeOut();
//	});
}