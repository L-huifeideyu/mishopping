$(function() {
	$("<link rel = 'stylesheet' type='text/css' href='css/base.css'>").prependTo("head");
	$("<link rel = 'stylesheet' type='text/css' href='css/header.css'>").prependTo("head");
	$("<link rel = 'stylesheet' type='text/css' href='css/footer.css'>").prependTo("head");
	$("<link rel=' icon' type='image/x-icon' href='favicon.ico'/>").prependTo("head");
	$("<link rel='shortcut icon' type='image/x-icon' href='favicon.ico'/>").prependTo("head");
	$.ajax({
		url: "http://127.0.0.1:3000/header.html",
		type: "get",
		success: function(res) {
			$("#header").replaceWith(res);
			//			var $btnSearch = $("#header>nav>div img"),
			//				$input = $btnSearch.parent().prev();
			//			$btnSearch.click(function() {
			//				console.log(11)
			//				var kw = $input.val().trim();
			//				if(kw !== "") {
			//					location.href = `products.html?kwords=${kw}`;
			//				}
			//			});
			//			$input.keyup(function(e) {
			//				if(e.keyCode == 13)
			//					$btnSearch.click();
			//			})
			//			if(location.search.indexOf("kwords") != -1) 
			//			{
			//				var kwords = decodeURI(
			//					location.search.split("=")[1]
			//				)
			//				$input.val(kwords)
			//			}
			//			$("#btnLogin").click(function(e){
			//				e.preventDefault();
			//				location.href = "login.html?back="+location.href;
			//			})
			//			$.ajax({
			//				type:"get",
			//				url:"http://127.0.0.1:3000/user/islogin",
			//				dataType:"json",
			//				success:function(res){
			//					if(res.islogin == 0)
			//					{
			//						$("#signout").show().next().hide();
			//					}else{
			//						$("#uname").html(res.uname);
			//						$("#signout").hide().next().show();
			//					}
			//				}
			//			});
			//			$("#btnSignout").click(function(){
			//				$.ajax({
			//					url:"http://127.0.0.1:3000/user/outlogin",
			//					type:"get",
			//					success:function(){
			//						location.reload();
			//					}
			//				})
			//			})
		}
	})
	$.ajax({
		url: "http://127.0.0.1:3000/footer.html",
		type: "get",
		success: function(res) {
			$("#footer").replaceWith(res)
		}
	})
})