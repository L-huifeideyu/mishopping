<template>
	<div>
		<header>
			<div class="top w">
				<div class="left fl">
					<ul>
						<li>
							<router-link to="/">小米商城</router-link>
						</li>
						<li>
							|
						</li>
						<li>
							<a href="javascript:void(0);">MIUI</a>
						</li>
						<li>
							|
						</li>
						<li>
							<a href="javascript:void(0);">loT</a>
						</li>
						<li>
							|
						</li>
						<li>
							<a href="javascript:void(0);">云服务</a>
						</li>
						<li>
							|
						</li>
						<li>
							<a href="javascript:void(0);">金融</a>
						</li>
						<li>
							|
						</li>
						<li>
							<a href="javascript:void(0);">有品</a>
						</li>
						<li>
							|
						</li>
						<li>
							<a href="javascript:void(0);">小爱开放平台</a>
						</li>
						<li>
							|
						</li>
						<li>
							<a href="javascript:void(0);">政企服务</a>
						</li>
						<li>
							|
						</li>
						<li>
							<a href="javascript:void(0);">下载App</a>
						</li>
						<li>
							|
						</li>
						<li>
							<a href="javascript:void(0);">Select Region</a>
						</li>
					</ul>
				</div>
				<div class="right fr">
					<ul v-show="islogin.out">
						<li>
							<a href="javascript:void(0);" @click.prev="toLogin">登陆</a>
						</li>
						<li>|</li>
						<li>
							<router-link to="/register">注册</router-link>
						</li>
						<li>|</li>
						<li>
							<a href='#' @click.prev="onSelfInfo">个人中心</a>
						</li>
						
						
						<li>
							<a href="#" @click.prev="onShoppingCart">购物车(0)</a>
						</li>
					</ul>
					<ul v-show="islogin.on">
						<li>
							<a href="javascript:void(0);" @click.prev="loginout">注销</a>
						</li>
						<li>|</li>
						<li>
							<a href="#" @click.prev="onSelfInfo">欢迎：{{uname}}</a>
						</li>
						<li>|</li>
						<li>
							<a href="#" @click.prev="onOrderCenter">我的订单</a>
						</li>
						
						
						<li>
							<a href="#" @click.prev="onShoppingCart">购物车(0)</a>
						</li>
					</ul>
				</div>
			</div>
		</header>
		<div class="logoSearch">
			<div class="container w clear">
				<div class="logo fl">
					<router-link to="/"><img src="../../static/img/logo_top.png" /></router-link>
				</div>
				<div class="title fl">
					<router-link to="/"><img src="../../static/img/yyymix.gif" /></router-link>
				</div>
				<div class="navbar fl">
					<ul>
						<li>
							<a href="javascript:void(0);">小米手机</a>
						</li>
						<li>
							<a href="javascript:void(0);">红米</a>
						</li>
						<li>
							<a href="javascript:void(0);">电视</a>
						</li>
						<li>
							<a href="javascript:void(0);">笔记本</a>
						</li>
						<li>
							<a href="javascript:void(0);">空调</a>
						</li>
						<li>
							<a href="javascript:void(0);">新品</a>
						</li>
						<li>
							<a href="javascript:void(0);">路由器</a>
						</li>
						<li>
							<a href="javascript:void(0);">智能硬件</a>
						</li>
						<li>
							<a href="javascript:void(0);">服务</a>
						</li>
						<li>
							<a href="javascript:void(0);">社区</a>
						</li>
					</ul>
				</div>
				<div class="search fr">
					<form>
						<div class="form clear">
							<input type="text" name="search" id="search" placeholder="小米8直降200元" />
							<input type="submit" value="" />
						</div>

					</form>
				</div>
			</div>
		</div>

	</div>
</template>

<script>
	export default {
		data:function(){
			return{
				path:'',
				islogin:{
					on:false,
					out:true,
				},
				uname:'',
				uid:'',
			}
		},
		methods:{
			toLogin(){
				this.path = this.$route.path;
				this.$router.push('/login' + this.path)
			},
			isLogin(){
				this.axios.get('/user/islogin')
				.then(res=>{
					//console.log(res.data)
					if(res.data.state == 'ok')
					{
						this.islogin.on = true;
						this.islogin.out = false;
						this.uname = res.data.uname;
						this.uid = res.data.uid
					}else{
						this.islogin.on = false;
						this.islogin.out = true;
						this.uname = '';
					}
				})
			},
			loginout(){
				this.axios.get('/user/loginout')
				.then(res=>{
					this.isLogin();
				})
			},
			onSelfInfo(){
				this.axios.get('/user/islogin').then(res=>{
					if(res.data.state == 'ok')
					{
						this.$router.push('/self_info/' + this.uid)
					}else{
						alert('您还没有登陆，请登陆！！！')
						this.toLogin()
					}
				})
			},
			onShoppingCart(){
				this.axios.get('/user/islogin').then(res=>{
					if(res.data.state == 'ok')
					{
						this.$router.push('/shopping_cart')
					}else{
						alert('您还没有登陆，请登陆！！！')
						this.toLogin()
					}
				})
			},
			onOrderCenter(){
				this.$router.push('/order_center/' + this.uid)
			}
		},
		mounted(){
			this.isLogin();
		}
	}
</script>

<style scoped>
	/*------------start header-------*/
	
	header {
		width: 100%;
		background: #333;
		height: 40px;
	}
	
	header .top {
		line-height: 40px;
	}
	
	header .top .left ul li {
		float: left;
		color: #ccc;
		font-size: 12px;
	}
	
	header .top .left ul li a {
		color: #b0b0b0;
		font-size: 12px;
		display: block;
		padding: 0 8px;
	}
	
	header .top .right ul li {
		float: left;
		color: #ccc;
		font-size: 12px;
	}
	
	header .top .right ul li a {
		color: #b0b0b0;
		font-size: 12px;
		display: block;
		padding: 0 8px;
	}
	
	header .top a {
		transition: all .3s;
	}
	
	header .top .right ul li a:hover,
	header .top .left ul li a:hover {
		color: #ffffff;
	}
	
	header .top .right ul li:last-child a {
		background: #FF6700 url(../../static/img/shop_car.png) no-repeat 17px 8px;
		width: 90px;
		text-align: right;
		color: #fff;
		transition: all .3s;
	}
	
	header .top .right ul li:last-child a:hover {
		background: #555 url(../../static/img/shop_car1.png) no-repeat 17px 8px;
		color: #b0b0b0;
	}
	/*--------------end header-------------*/
	/*---------------start logoSearch----------*/
	
	.logoSearch {
		height: 100px;
	}
	
	.logoSearch a {
		display: block;
	}
	
	.logoSearch .container {
		line-height: 100px;
	}
	
	.logoSearch .container .logo img {
		vertical-align: middle;
	}
	
	.logoSearch .container .title img {
		vertical-align: middle;
	}
	
	.logoSearch .container .navbar ul li {
		float: left;
		height: 100px;
		line-height: 100px;
	}
	
	.logoSearch .container .navbar ul li a {
		font-size: 16px;
		padding: 0 10px;
		transition: all .3s;
	}
	
	.logoSearch .container .navbar ul li a:hover {
		color: #FF6700;
	}
	
	.logoSearch .container .search {
		height: 100px;
		line-height: 100px;
	}
	
	.logoSearch .container .search .form {
		margin-top: 30px;
		border: 1px solid #b0b0b0;
		transition: all .3s;
	}
	
	.logoSearch .container .search .form:hover {
		border: 1px solid #FF6700;
	}
	
	.logoSearch .container .search input {
		display: block;
		float: left;
		height: 40px;
		border: 0;
		outline: 0;
	}
	
	.logoSearch .container .search input[type="text"] {
		width: 260px;
	}
	
	.logoSearch .container .search input[type="submit"] {
		width: 45px;
		background: #b0b0b0 url(../../static/img/img-sp_ll.png) no-repeat 1px -5px;
		cursor: pointer;
	}
	/*---------------end logoSearch----------*/
</style>