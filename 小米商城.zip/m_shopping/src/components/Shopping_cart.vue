<template>
	<div>
		<Header></Header>
		<div class="xiantiao"></div>
		<div class="gwcxqbj">
			<div class="gwcxd center">
				<div class="top2 center">
					<div class="sub_top fl">
						<input type="checkbox" value="quanxuan" class="quanxuan">全选
					</div>
					<div class="sub_top fl">商品名称</div>
					<div class="sub_top fl">单价</div>
					<div class="sub_top fl">数量</div>
					<div class="sub_top fl">小计</div>
					<div class="sub_top fr">操作</div>
					<div class="clear"></div>
				</div>
				<div class="content2 center">
					<div class="sub_content fl ">
						<input type="checkbox" value="quanxuan" class="quanxuan">
					</div>
					<div class="sub_content fl"><img src="../../static/img/gwc_xiaomi6.jpg"></div>
					<div class="sub_content fl ft20">小米6全网通6GB内存+64GB 亮黑色</div>
					<div class="sub_content fl ">2499元</div>
					<div class="sub_content fl">
						<input class="shuliang" type="number" value="1" step="1" min="1">
					</div>
					<div class="sub_content fl">2499元</div>
					<div class="sub_content fl">
						<a href="">×</a>
					</div>
					<div class="clear"></div>
				</div>
				<div class="content2 center">
					<div class="sub_content fl ">
						<input type="checkbox" value="quanxuan" class="quanxuan">
					</div>
					<div class="sub_content fl"><img src="../../static/img/gwc_xiaomi6.jpg"></div>
					<div class="sub_content fl ft20">小米6全网通6GB内存+64GB 亮黑色</div>
					<div class="sub_content fl ">2499元</div>
					<div class="sub_content fl">
						<input class="shuliang" type="number" value="1" step="1" min="1">
					</div>
					<div class="sub_content fl">2499元</div>
					<div class="sub_content fl">
						<a href="">×</a>
					</div>
					<div class="clear"></div>
				</div>
			</div>
			<div class="jiesuandan mt20 center">
				<div class="tishi fl ml20">
					<ul>
						<li>
							<a href="./liebiao.html">继续购物</a>
						</li>
						<li>|</li>
						<li>共<span>2</span>件商品，已选择<span>1</span>件</li>
						<div class="clear"></div>
					</ul>
				</div>
				<div class="jiesuan fr">
					<div class="jiesuanjiage fl">合计（不含运费）：<span>2499.00元</span></div>
					<div class="jsanniu fr"><input class="jsan" type="submit" name="jiesuan" value="去结算"></div>
					<div class="clear"></div>
				</div>
				<div class="clear"></div>
			</div>

		</div>
		<Footer></Footer>
	</div>
</template>

<script>
	import Header from './Header'
	import Footer from './Footer'
	export default {
		components: {
			Header,
			Footer
		}
	}
</script>

<style scoped>
	.xiantiao {
		width: 100%;
		height: 2px;
		background: #ff6700;
	}
	/*购物车详单*/
	
	.gwcxqbj {
		width: 100%;
		height: 400px;
		background: rgb(245, 245, 245);
		padding-bottom: 20px;
	}
	
	.gwcxqbj .gwcxd {
		background: #fff;
		width: 1226px;
		height: auto;
		padding-top: 30px;
	}
	
	.gwcxqbj .gwcxd .top2 {
		width: 1226px;
		height: 70px;
	}
	
	.gwcxqbj .gwcxd .top2 .sub_top {
		width: 100px;
		height: 70px;
		line-height: 36px;
		margin-right: 0px;
		margin-top: 0px;
		margin-left: 30px;
	}
	
	.gwcxqbj .gwcxd .top2 .sub_top:nth-of-type(2) {
		margin-left: 100px;
	}
	
	.gwcxqbj .gwcxd .top2 .sub_top:nth-of-type(3) {
		margin-left: 300px;
	}
	
	.gwcxqbj .gwcxd .top2 .sub_top:nth-of-type(4) {
		margin-left: 60px;
	}
	
	.gwcxqbj .gwcxd .top2 .sub_top:nth-of-type(5) {
		margin-left: 60px;
	}
	
	.gwcxqbj .gwcxd .top2 .sub_top .quanxuan {
		width: 18px;
		height: 18px;
		border: 1px solid #ccc;
		background: none;
	}
	
	.gwcxqbj .gwcxd .content2 {
		width: 1226px;
		height: 120px;
		border-top: 1px solid #ccc;
	}
	
	.gwcxqbj .gwcxd .content2 .sub_content {
		width: 50px;
		height: 120px;
		line-height: 120px;
		margin-right: 0px;
	}
	
	.gwcxqbj .gwcxd .sub_content .quanxuan {
		width: 18px;
		height: 18px;
		border: 1px solid #ccc;
		background: none;
	}
	
	.gwcxqbj .gwcxd .content2 .sub_content img {
		vertical-align: middle;
	}
	
	.gwcxqbj .gwcxd .content2 .sub_content:nth-of-type(1) {
		margin-left: 30px;
	}
	
	.gwcxqbj .gwcxd .content2 .sub_content:nth-of-type(2) {
		margin-left: 35px;
	}
	
	.gwcxqbj .gwcxd .content2 .sub_content:nth-of-type(3) {
		margin-left: 55px;
		width: 330px;
	}
	
	.gwcxqbj .gwcxd .content2 .sub_content:nth-of-type(4) {
		margin-left: 55px;
	}
	
	.gwcxqbj .gwcxd .content2 .sub_content:nth-of-type(5) {
		margin-left: 115px;
	}
	
	.gwcxqbj .gwcxd .content2 .sub_content:nth-of-type(6) {
		margin-left: 115px;
		color: #ff6700;
	}
	
	.gwcxqbj .gwcxd .content2 .sub_content:nth-of-type(7) {
		margin-left: 145px;
		font-size: 25px;
	}
	
	.gwcxqbj .gwcxd .content2 .sub_content .shuliang {
		width: 70px;
		height: 35px;
		border: 2px solid #ccc;
		text-align: center;
		font-size: 16px;
		color: #ff6700;
	}
	
	.gwcxqbj .gwcxd .content2 .sub_content a {
		display: block;
		width: 20px;
		height: 20px;
		border-radius: 10px;
		color: #000;
	}
	
	.gwcxqbj .gwcxd .content2 .sub_content a:hover {
		color: #ff6700;
	}
	/*结算单*/
	
	.jiesuandan {
		width: 1226px;
		height: 50px;
		background: #fff;
	}
	
	.jiesuandan .tishi {
		width: 400px;
		height: 50px;
		line-height: 50px;
	}
	
	.jiesuandan .tishi ul li {
		float: left;
		font-size: 14px;
		display: inline-block;
		padding: 0 10px;
		color: #666;
	}
	
	.jiesuandan .tishi ul li a {
		color: #666;
	}
	
	.jiesuandan .tishi ul li a:hover {
		color: #ff6700;
	}
	
	.jiesuandan .tishi ul li span {
		display: inline-block;
		color: #ff6700;
		margin: 0 4px;
	}
	
	.jiesuandan .jiesuan {
		width: 500px;
		height: 50px;
		line-height: 50px;
		font-size: 14px;
		color: #ff6700;
	}
	
	.jiesuandan .jiesuan .jiesuanjiage span {
		font-size: 24px;
		font-weight: bold;
	}
	
	.jiesuandan .jiesuan .jsanniu .jsan {
		width: 200px;
		height: 50px;
		color: #fff;
		background: rgb(255, 103, 0);
		font-size: 20px;
		border: none;
		cursor: pointer;
	}
	
	.jiesuandan .jiesuan .jsanniu .jsan:hover {
		background: rgb(242, 88, 7);
	}
</style>