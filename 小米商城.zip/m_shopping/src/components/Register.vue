<template>
	<div class="body">
		<table></table>
		<div class="register">
			<form action="" method="post" class="center">
				<div class="register_center clearMargin">
					<div class="register_top">
						<h3>会员注册</h3>
						<router-link to="/">小米商城</router-link>
					</div>
					<div class="register_main">
						<div class="uname">
							<label for="uname">用&nbsp;&nbsp;户&nbsp;&nbsp;名：</label><input type="text" name="uname" id="uname" placeholder="请输入你的用户名" autofocus v-model="uname" required/><span :style="isUnameStyle">{{isUname}}</span>
						</div>
						<div class="upwd">
							<label for="upwd">密&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;码：</label><input type="password" name="upwd" id="upwd" placeholder="请输入你的密码" v-model="upwd" required/><span :style="isUpwdStyle">{{isUpwd}}</span>
						</div>
						<div class="cupwd">
							<label for="cupwd">确认密码：</label><input type="password" name="cupwd" id="cupwd" placeholder="请确认你的密码" v-model="cupwd" required/><span :style="isCupwdStyle">{{isCupwd}}</span>
						</div>
						<div class="phone">
							<label for="phone">手&nbsp;&nbsp;机&nbsp;&nbsp;号：</label><input type="text" name="phone" id="phone" placeholder="请填写正确的手机号" v-model="phone" required/><span :style="isPhoneStyle">{{isPhone}}</span>
						</div>
						<div class="email">
							<label for="email">电子邮箱：</label><input type="text" name="email" id="email" placeholder="请填写正确的邮箱" v-model="email" required/><span :style="isEmailStyle" @keyup.13="register">{{isEmail}}</span>
						</div>
					</div>
					<div class="register_submit">
						<input type="button" id="" name="" value="立 即 注 册" @click="register" />
					</div>
				</div>
			</form>
		</div>
	</div>
</template>

<script>
	import Qs from 'qs'
	export default {
		data: function() {
			return {
				uname: "",
				isUname: "",
				unameReg: /^([A-Za-z0-9_\-\u4e00-\u9fa5]{6,20})$/,
				isUnameStyle: {
					color: '#ccc'
				},
				upwd: "",
				isUpwd: "",
				upwdReg: /^(\w|@|\.|\-){6,20}$/,
				isUpwdStyle: {
					color: '#ccc'
				},
				cupwd: "",
				isCupwd: "",
				isCupwdStyle: {
					color: '#ccc'
				},
				phone: "",
				isPhone: "",
				phoneReg: /^((\+86|0086)?\s*1[3-8]\d{9})$/,
				isPhoneStyle: {
					color: '#ccc'
				},
				email: "",
				isEmail: "",
				EmailReg: /^(\w[-\w.+]*@([A-Za-z0-9][-A-Za-z0-9]+\.)+[A-Za-z]{2,14})$/,
				isEmailStyle: {
					color: '#ccc'
				},
				disable: 1,
				path: "",
				unameDis:false,
				upwdDis:false,
				cpwdDis:false,
				phoneDis:false,
				emailDis:false,
			}
		},
		methods: {
			register() {
				var bool = this.unameDis&&this.upwdDis&&this.cpwdDis&&this.phoneDis&&this.emailDis
				if(bool) {
					this.axios.post("/user/register", Qs.stringify({
							uname: this.uname,
							upwd: this.upwd,
							phone: this.phone,
							email: this.email
						}))
						.then(res => {
							if(res.data.state == 'ok') {
								alert("注册成功，即将跳转登陆界面！")
								this.path = this.$route.path;
								this.$router.push('/login' + this.path)

							}
							else {
								alert("系统繁忙，请稍候再试")
							}
						})
				}else{
					alert("请检查注册信息！！！")
				}

			}

		},
		created() { //console.log(this.unameReg)
		},
		watch: {
			uname() {
				this.axios.post("/user/selectUname", Qs.stringify({
						uname: this.uname
					}))
					.then(res => {
						if(res.data.state == 'ok') {
							this.isUnameStyle.color = 'red'
							this.isUname = '用户名已存在'
							this.unameDis = false;
						}
						else if(this.unameReg.test(this.uname)) {
							this.isUnameStyle.color = 'green'
							this.isUname = '用户名可用'
							this.unameDis = true;
						}
						else {
							this.isUnameStyle.color = 'red'
							this.isUname = '请输入6~20位合法的用户名'
							this.unameDis = false;
						}
					})
			},
			upwd() {
				if(this.upwdReg.test(this.upwd)) {
					this.isUpwdStyle.color = 'green'
					this.isUpwd = '密码可用'
					this.upwdDis = true;
				}
				else {
					this.isUpwdStyle.color = 'red'
					this.isUpwd = '请输入6~20位合法的密码'
					this.upwdDis = false;
				}
			},
			cupwd() {
				if(this.cupwd == this.upwd) {
					this.isCupwdStyle.color = 'green'
					this.isCupwd = 'ok'
					this.cpwdDis = true;
				}
				else {
					this.isCupwdStyle.color = 'red'
					this.isCupwd = '密码不一致'
					this.cpwdDis = false;
				}
			},
			phone() {
				this.axios.post("/user/selectPhone", Qs.stringify({
						phone: this.phone
					}))
					.then(res => {
						if(res.data.state == 'ok') {
							this.isPhoneStyle.color = 'red'
							this.isPhone = '手机号已存在'
							this.phoneDis = false;
						}
						else if(this.phoneReg.test(this.phone)) {
							this.isPhoneStyle.color = 'green'
							this.isPhone = '手机号可用'
							this.phoneDis = true;
						}
						else {
							this.isPhoneStyle.color = 'red'
							this.isPhone = '请输入合法的手机号'
							this.phoneDis = false;
						}
					})
			},
			email() {
				this.axios.post("/user/selectEmail", Qs.stringify({
						email: this.email
					}))
					.then(res => {
						if(res.data.state == 'ok') {
							this.isEmailStyle.color = 'red'
							this.isEmail = '邮箱已存在'
							this.emailDis = false;
						}
						else
						if(this.EmailReg.test(this.email)) {
							this.isEmailStyle.color = 'green'
							this.isEmail = '邮箱可用'
							this.emailDis = true;
						}
						else {
							this.isEmailStyle.color = 'red'
							this.isEmail = '请输入合法的邮箱'
							this.emailDis = false;
						}
					})
			}

		}

	}
</script>

<style scoped>
	.body {
		width: 100%;
		height: 1000px;
		background: rgba(20, 33, 42);
	}
	
	form {
		width: 1000px;
		height: 550px;
		margin: 20px auto;
		background: #fff;
		border-radius: 6px;
		box-shadow: 0 0 10px 2px #CCCCCC;
	}
	
	.register_center {
		width: 760px;
		margin: 100px auto;
		padding-top: 20px;
	}
	
	.register_center .register_top {
		margin: 10px 0;
		height: 50px;
		border-bottom: 3px solid #FF6700;
	}
	
	.register_center .register_top h3 {
		height: 40px;
		line-height: 40px;
		font-size: 20px;
		font-weight: 800;
		float: left;
		margin-top: 5px;
	}
	
	.register_center .register_top a {
		display: block;
		float: right;
		font-size: 13px;
		font-weight: bold;
		color: #FF6700;
		margin-top: 10px;
	}
	
	.register_center .register_top a:hover {
		color: coral;
	}
	
	.register_center .register_main {
		padding: 10px 0;
		padding-left: 45px;
		margin: 0 auto;
	}
	
	.register_center .register_main>div {
		font-size: 16px;
		height: 40px;
		line-height: 40px;
		margin: 10px 0;
	}
	
	.register_center .register_main>div input {
		height: 30px;
		width: 220px;
		padding: 5px 10px;
		border: 1px solid #ccc;
		outline-color: #FF6700;
		outline-width: 1px;
	}
	
	.register_center .register_main>div span {
		color: #ccc;
		font-size: 12px;
		display: inline-block;
		margin-left: 45px;
	}
	
	.register_center .register_submit {
		margin: 20px auto;
	}
	
	.register_center .register_submit input {
		display: block;
		height: 50px;
		background: #FF6700;
		color: #fff;
		font-size: 20px;
		font-weight: bold;
		width: 450px;
		margin: 0 auto;
		border: 0;
		outline-color: orange;
		cursor: pointer;
	}
</style>