<template>
	<div>
		<Header></Header>
		<div class="detail w clear">
			<div class="title">
				<h3>{{data.title}}</h3>
			</div>
			<div class="detail_main">
				<div class="d_img">
					<img :src="data.img" />
				</div>
				<div class="jieshao">
					<h4>{{data.title}}</h4>
					<p class="subtitle">{{data.subtitle}}</p>
					<p class="price">￥{{data.price.toFixed(2)}}</p>
					<div class="spec">
						<p>选择版本</p>
						<div class="chose">
							<!--<span class="active">全网通6G+64G</span>-->
							<span v-for="(spec,index) in specs" @click="choseSpec(index)" :class="{active:active == index}">{{spec}}</span>
						</div>
					</div>
					<div class="color">
						<p>选择颜色</p>
						<span>{{data.color}}</span>
					</div>
					<div class="total clear">
						<span>{{chose}}</span>
						<span>￥{{data.price.toFixed(2)}}</span>
					</div>
					<div class="jiesuan clear">
						<router-link to="" class="button">立即选购</router-link>
						<router-link :to="`/shopping_cart?lid=${data.lid}`" class="button">加入购物车</router-link>
					</div>
				</div>

			</div>
		</div>
		<Footer></Footer>
	</div>
</template>

<script>
	import Header from './Header'
	import Footer from './Footer'
	export default {
		components: {
			Header,
			Footer
		},
		data:function(){
			return{
				data:{price:0},
				lid:0,
				specs:[],
				chose:"",
				active:0
			}
		},
		methods:{
			choseSpec(index){
				this.active = index;
				this.chose = this.specs[index];
				//console.log(this.active)
			},
			getMsg(){
				this.lid = this.$route.params.lid
				//console.log(this.lid)
				this.axios.get("/details",{
					params:{
						lid:this.lid
					}
				})
				.then(res=>{
					this.data = res.data[0]
					
					if(this.data.spec.indexOf('-') == -1)
					{
						
						this.specs.push(this.data.spec);
						this.chose = this.specs[0]						
					}else{
						console.log(22)
						this.specs = this.data.spec.split('-')
						this.chose = this.specs[0]
					}
				})
			},
			addShopping_cart(){
				
			}
		},
		mounted(){
			this.getMsg();
		}
	}
</script>

<style scoped>
	/*.detail{
		height: 600px;
	}*/
	.detail .title {
		height: 58px;
		line-height: 58px;
		font-size: 24px;
		font-weight: bold;
	}
	
	.detail .detail_main .d_img {
		height: 560px;
		width: 560px;
		border: 1px solid #ccc;
		float: left;
	}
	
	.detail .detail_main .d_img img {
		width: 100%;
	}
	
	.detail .detail_main .jieshao {
		height: 560px;
		width: 620px;
		background: rgba(250,250,250);
		float: right;
		padding: 5px 15px;
	}
	.detail .detail_main .jieshao h4{
		height: 48px;
		line-height: 48px;
		font-size: 18px;
		font-weight: 800;
	}
	.detail .detail_main .jieshao .subtitle{
		font-size: 14px;
		color:#999;
		height: 35px;
		line-height: 35px;
	}
	.detail .detail_main .jieshao .price{
		font-size: 20px;
		color: #FF6700;
		height: 40px;
		line-height: 40px;
	}
	.detail .detail_main .jieshao .spec{
		height: 160px;
	}
	.detail .detail_main .jieshao .spec>p{
		font-size: 18px;
		height: 48px;
		line-height: 48px;
	}
	.detail .detail_main .jieshao .spec .chose{
		height: 50px;
	}
	.detail .detail_main .jieshao .spec .chose span{
		font-size: 13px;
		height: 45px;
		line-height: 45px;
		width: 250px;
		text-align: center;
		border:1px solid #999;
		float: left;
		cursor: pointer;
		margin-top:8px ;
	}
	.detail .detail_main .jieshao .spec .chose span:hover{
		border-color: #FF6700;
		color: #FF6700;
	}
	.detail .detail_main .jieshao .spec .chose span.active{
		color: #FF6700;
		border-color: #FF6700;
	}
	.detail .detail_main .jieshao .spec .chose span:nth-child(2){
		margin-left: 40px;
	}
	.detail .detail_main .jieshao .color{
		height: 130px;
	}
	.detail .detail_main .jieshao .color p{
		font-size: 18px;
		height: 48px;
		line-height: 48px;
	}
	.detail .detail_main .jieshao .color span{
		height: 45px;
		line-height: 45px;
		width: 200px;
		text-align: center;
		border:1px solid #FF6700;
		float: left;
		color: #FF6700;
		cursor: pointer;
	}
	.detail .detail_main .jieshao .total{
		height: 100px;
		line-height: 100px;
		background: #fff;
	}
	.detail .detail_main .jieshao .total span{
		font-size: 18px;
	}
	.detail .detail_main .jieshao .total span:last-child{
		float: right;
		color: #FF6700;
	}
	.detail .detail_main .jieshao .jiesuan{
		margin-top: 5px;
		padding-left: 100px;
		box-sizing: border-box;
	}
	.detail .detail_main .jieshao .jiesuan .button{
		display: inline-block;
		text-align: center;
		background: #FF6700;
		color: #fff;
		font-size: 22px;
		font-weight: bold;
		border: 1px solid;
		outline: none;
		height: 45px;
		line-height: 45px;
		width: 150px;
		cursor: pointer;
	}
	.detail .detail_main .jieshao .jiesuan .button:hover{
		border:1px solid #000
	}
	.detail .detail_main .jieshao .jiesuan .button:last-child{
		margin-left:60px ;
	}
</style>