<template>
	<div>
		<Header></Header>
		<Index></Index>
		<Footer></Footer>
	</div>

</template>

<script>
	import Index from './Index'
	import Header from './Header'
	import Footer from './Footer'
	export default {
		components: {
			Header,
			Index,
			Footer
		},
	}
</script>

<style>

</style>