<template>
	<div>
		<Header></Header>
		<div class="grzxbj">
			<div class="selfinfo center">
				<div class="lfnav fl">
					<div class="ddzx">订单中心</div>
					<div class="subddzx">
						<ul>
							<li>
								<a href="" style="color:#ff6700;font-weight:bold;">我的订单</a>
							</li>
							<li>
								<a href="">意外保</a>
							</li>
							<li>
								<a href="">团购订单</a>
							</li>
							<li>
								<a href="">评价晒单</a>
							</li>
						</ul>
					</div>
					<div class="ddzx">个人中心</div>
					<div class="subddzx">
						<ul>
							<li>
								<a href="#" @click.prev="onSelfInfo">我的个人中心</a>
							</li>
							<li>
								<a href="">消息通知</a>
							</li>
							<li>
								<a href="">优惠券</a>
							</li>
							<li>
								<a href="">收货地址</a>
							</li>
						</ul>
					</div>
				</div>
				<div class="rtcont fr">
					<div class="ddzxbt">交易订单</div>
					<div class="ddxq">
						<div class="ddspt fl"><img src="../../static/img/gwc_xiaomi6.jpg" alt=""></div>
						<div class="ddbh fl">订单号:1705205643098724</div>
						<div class="ztxx fr">
							<ul>
								<li>已发货</li>
								<li>￥2499.00</li>
								<li>2017/05/20 13:30</li>
								<li>
									<a href="">订单详情></a>
								</li>
								<div class="clear"></div>
							</ul>
						</div>
						<div class="clear"></div>
					</div>
					<div class="ddxq">
						<div class="ddspt fl"><img src="../../static/img/liebiao_hongmin4_dd.jpg" alt=""></div>
						<div class="ddbh fl">订单号:170526435444865</div>
						<div class="ztxx fr">
							<ul>
								<li>已发货</li>
								<li>￥1999.00</li>
								<li>2017/05/26 14:02</li>
								<li>
									<a href="">订单详情></a>
								</li>
								<div class="clear"></div>
							</ul>
						</div>
						<div class="clear"></div>
					</div>
				</div>
				<div class="clear"></div>
			</div>
		</div>
		<Footer></Footer>
	</div>
</template>

<script>
	import Header　 from './Header'
	import Footer from './Footer'
	import Qs from 'qs'
	export default {
		components: {
			Header,
			Footer
		},
		data:function(){
			return{
				uid:'',
			}
		},
		methods:{
			onSelfInfo(){
				this.uid = this.$route.params.uid
				this.$router.push('/self_info/' + this.uid)
			},
			
		},
		
	}
</script>

<style scoped>
	.grzxbj {
		width: 100%;
		height: auto;
		background: rgb(245, 245, 245);
		padding-bottom: 20px;
		padding-top: 20px;
	}
	
	.grzxbj .selfinfo {
		width: 1226px;
	}
	
	.grzxbj .selfinfo .lfnav {
		width: 234px;
		height: 500px;
		background: #fff;
	}
	
	.grzxbj .selfinfo .lfnav .ddzx {
		width: 234px;
		height: 40px;
		line-height: 40px;
		font-size: 19px;
		margin: 30px 20px 10px 40px;
		color: rgb(51, 51, 51);
	}
	
	.grzxbj .selfinfo .lfnav .subddzx ul li {
		display: block;
		width: 194px;
		height: 40px;
		line-height: 40px;
		padding-left: 40px;
	}
	
	.grzxbj .selfinfo .lfnav .subddzx ul li a {
		color: rgb(117, 117, 117);
	}
	
	.grzxbj .selfinfo .lfnav .subddzx ul li a:hover {
		color: rgb(51, 51, 51);
	}
	
	.grzxbj .selfinfo .rtcont .ddxq {
		width: 938px;
		height: 120px;
		line-height: 120px;
		font-size: 17px;
		color: rgb(117, 117, 117);
		border-bottom: 1px solid #ccc;
		padding-left: 40px;
	}
	
	.grzxbj .selfinfo .rtcont .ddxq .ddspt {
		width: 80px;
		height: 80px;
		margin: 19px 25px 0 0;
		border: 1px solid #aaa;
	}
	
	.grzxbj .selfinfo .rtcont .ddxq .ztxx ul li {
		display: inline-block;
		width: 130px;
		height: 60px;
		line-height: 60px;
		float: left;
		border-left: 1px solid #aaa;
		margin-top: 30px;
		text-align: center;
	}
	
	.grzxbj .selfinfo .rtcont .ddxq .ztxx ul li a {
		color: rgb(117, 117, 117);
	}
	
	.grzxbj .selfinfo .rtcont .ddxq .ztxx ul li a:hover {
		color: #ff6700;
	}
</style>