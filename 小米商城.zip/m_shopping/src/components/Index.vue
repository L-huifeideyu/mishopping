<template>
	<div>
		<div class="banner">
			<div class="container w clear">
				<div class="carrousel">
					<div class="bannerList">
						<ul>
							<li v-for="(img,index) in imgArr" @click="setIndex(index)" :data-target="img.cid" :class="{active:index == mark}" :key="index"></li>
						</ul>
					</div>
					<div class="bannerImg">
						<router-link :to="`detail/${img.lid}`" v-for="(img,i) in imgArr" :key="i"><img :src="img.img" :id="img.cid" v-show="i == mark" @mouseenter="mouseenter()" @mouseleave="mouseleave()" /></router-link>

					</div>
					<div class="prev" @click="clickleft()"></div>
					<div class="next" @click="clickright()"></div>
				</div>
				<div class="list">
					<ul>
						<li>
							<a href="javascript:void(0);">手机 电话卡</a>
							<div class="xuanxiang clear">
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm6_80.png" /><span class="text">小米6</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/5c_80.png" /><span class="text">小米手机5c</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xmNOTE2-80.jpg" /><span class="text">小米Note2</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5S-80.jpg" /><span class="text">小米5s</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5Splus.jpg" /><span class="text">小米5s Plus</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/MIX-80.jpg" /><span class="text">小米MIX</span></a>
									</li>
								</ul>
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5-80.jpg" /><span class="text">小米手机5</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hmn4x80.png" /><span class="text">红米Note 4X</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hmnote4-80.jpg" /><span class="text">红米Note4</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4x_80.png" /><span class="text">红米4x</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4-80.jpg" /><span class="text">红米4</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4A-80.jpg" /><span class="text">红米4A</span></a>
									</li>
								</ul>
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/compare.jpg" /><span class="text">对比手机</span></a>
									</li>
									<li>
										<a href=""><img src="../../static/img/mimobile.jpg" /><span class="text">小米移动电话卡</span></a>
									</li>
								</ul>
							</div>
						</li>
						<li>
							<a href="javascript:void(0);">电视 盒子</a>
							<div class="xuanxiang clear">
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm6_80.png" /><span class="text">小米6</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/5c_80.png" /><span class="text">小米手机5c</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xmNOTE2-80.jpg" /><span class="text">小米Note2</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5S-80.jpg" /><span class="text">小米5s</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5Splus.jpg" /><span class="text">小米5s Plus</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/MIX-80.jpg" /><span class="text">小米MIX</span></a>
									</li>
								</ul>
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5-80.jpg" /><span class="text">小米手机5</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hmn4x80.png" /><span class="text">红米Note 4X</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hmnote4-80.jpg" /><span class="text">红米Note4</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4x_80.png" /><span class="text">红米4x</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4-80.jpg" /><span class="text">红米4</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4A-80.jpg" /><span class="text">红米4A</span></a>
									</li>
								</ul>
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/compare.jpg" /><span class="text">对比手机</span></a>
									</li>
									<li>
										<a href=""><img src="../../static/img/mimobile.jpg" /><span class="text">小米移动电话卡</span></a>
									</li>
								</ul>
							</div>
						</li>
						<li>
							<a href="javascript:void(0);">笔记本 平板</a>
							<div class="xuanxiang clear">
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm6_80.png" /><span class="text">小米6</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/5c_80.png" /><span class="text">小米手机5c</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xmNOTE2-80.jpg" /><span class="text">小米Note2</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5S-80.jpg" /><span class="text">小米5s</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5Splus.jpg" /><span class="text">小米5s Plus</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/MIX-80.jpg" /><span class="text">小米MIX</span></a>
									</li>
								</ul>
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5-80.jpg" /><span class="text">小米手机5</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hmn4x80.png" /><span class="text">红米Note 4X</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hmnote4-80.jpg" /><span class="text">红米Note4</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4x_80.png" /><span class="text">红米4x</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4-80.jpg" /><span class="text">红米4</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4A-80.jpg" /><span class="text">红米4A</span></a>
									</li>
								</ul>
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/compare.jpg" /><span class="text">对比手机</span></a>
									</li>
									<li>
										<a href=""><img src="../../static/img/mimobile.jpg" /><span class="text">小米移动电话卡</span></a>
									</li>
								</ul>
							</div>
						</li>
						<li>
							<a href="javascript:void(0);">家电 插线板</a>
							<div class="xuanxiang clear">
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm6_80.png" /><span class="text">小米6</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/5c_80.png" /><span class="text">小米手机5c</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xmNOTE2-80.jpg" /><span class="text">小米Note2</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5S-80.jpg" /><span class="text">小米5s</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5Splus.jpg" /><span class="text">小米5s Plus</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/MIX-80.jpg" /><span class="text">小米MIX</span></a>
									</li>
								</ul>
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5-80.jpg" /><span class="text">小米手机5</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hmn4x80.png" /><span class="text">红米Note 4X</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hmnote4-80.jpg" /><span class="text">红米Note4</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4x_80.png" /><span class="text">红米4x</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4-80.jpg" /><span class="text">红米4</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4A-80.jpg" /><span class="text">红米4A</span></a>
									</li>
								</ul>
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/compare.jpg" /><span class="text">对比手机</span></a>
									</li>
									<li>
										<a href=""><img src="../../static/img/mimobile.jpg" /><span class="text">小米移动电话卡</span></a>
									</li>
								</ul>
							</div>
						</li>
						<li>
							<a href="javascript:void(0);">出行 穿戴</a>
							<div class="xuanxiang clear">
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm6_80.png" /><span class="text">小米6</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/5c_80.png" /><span class="text">小米手机5c</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xmNOTE2-80.jpg" /><span class="text">小米Note2</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5S-80.jpg" /><span class="text">小米5s</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5Splus.jpg" /><span class="text">小米5s Plus</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/MIX-80.jpg" /><span class="text">小米MIX</span></a>
									</li>
								</ul>
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5-80.jpg" /><span class="text">小米手机5</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hmn4x80.png" /><span class="text">红米Note 4X</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hmnote4-80.jpg" /><span class="text">红米Note4</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4x_80.png" /><span class="text">红米4x</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4-80.jpg" /><span class="text">红米4</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4A-80.jpg" /><span class="text">红米4A</span></a>
									</li>
								</ul>
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/compare.jpg" /><span class="text">对比手机</span></a>
									</li>
									<li>
										<a href=""><img src="../../static/img/mimobile.jpg" /><span class="text">小米移动电话卡</span></a>
									</li>
								</ul>
							</div>
						</li>
						<li>
							<a href="javascript:void(0);">智能 路由器</a>
							<div class="xuanxiang clear">
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm6_80.png" /><span class="text">小米6</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/5c_80.png" /><span class="text">小米手机5c</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xmNOTE2-80.jpg" /><span class="text">小米Note2</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5S-80.jpg" /><span class="text">小米5s</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5Splus.jpg" /><span class="text">小米5s Plus</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/MIX-80.jpg" /><span class="text">小米MIX</span></a>
									</li>
								</ul>
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5-80.jpg" /><span class="text">小米手机5</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hmn4x80.png" /><span class="text">红米Note 4X</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hmnote4-80.jpg" /><span class="text">红米Note4</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4x_80.png" /><span class="text">红米4x</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4-80.jpg" /><span class="text">红米4</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4A-80.jpg" /><span class="text">红米4A</span></a>
									</li>
								</ul>
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/compare.jpg" /><span class="text">对比手机</span></a>
									</li>
									<li>
										<a href=""><img src="../../static/img/mimobile.jpg" /><span class="text">小米移动电话卡</span></a>
									</li>
								</ul>
							</div>
						</li>
						<li>
							<a href="javascript:void(0);">电源 配件</a>
							<div class="xuanxiang clear">
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm6_80.png" /><span class="text">小米6</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/5c_80.png" /><span class="text">小米手机5c</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xmNOTE2-80.jpg" /><span class="text">小米Note2</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5S-80.jpg" /><span class="text">小米5s</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5Splus.jpg" /><span class="text">小米5s Plus</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/MIX-80.jpg" /><span class="text">小米MIX</span></a>
									</li>
								</ul>
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5-80.jpg" /><span class="text">小米手机5</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hmn4x80.png" /><span class="text">红米Note 4X</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hmnote4-80.jpg" /><span class="text">红米Note4</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4x_80.png" /><span class="text">红米4x</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4-80.jpg" /><span class="text">红米4</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4A-80.jpg" /><span class="text">红米4A</span></a>
									</li>
								</ul>
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/compare.jpg" /><span class="text">对比手机</span></a>
									</li>
									<li>
										<a href=""><img src="../../static/img/mimobile.jpg" /><span class="text">小米移动电话卡</span></a>
									</li>
								</ul>
							</div>
						</li>
						<li>
							<a href="javascript:void(0);">健康 儿童</a>
							<div class="xuanxiang clear">
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm6_80.png" /><span class="text">小米6</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/5c_80.png" /><span class="text">小米手机5c</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xmNOTE2-80.jpg" /><span class="text">小米Note2</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5S-80.jpg" /><span class="text">小米5s</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5Splus.jpg" /><span class="text">小米5s Plus</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/MIX-80.jpg" /><span class="text">小米MIX</span></a>
									</li>
								</ul>
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5-80.jpg" /><span class="text">小米手机5</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hmn4x80.png" /><span class="text">红米Note 4X</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hmnote4-80.jpg" /><span class="text">红米Note4</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4x_80.png" /><span class="text">红米4x</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4-80.jpg" /><span class="text">红米4</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4A-80.jpg" /><span class="text">红米4A</span></a>
									</li>
								</ul>
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/compare.jpg" /><span class="text">对比手机</span></a>
									</li>
									<li>
										<a href=""><img src="../../static/img/mimobile.jpg" /><span class="text">小米移动电话卡</span></a>
									</li>
								</ul>
							</div>
						</li>
						<li>
							<a href="javascript:void(0);">耳机 音响</a>
							<div class="xuanxiang clear">
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm6_80.png" /><span class="text">小米6</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/5c_80.png" /><span class="text">小米手机5c</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xmNOTE2-80.jpg" /><span class="text">小米Note2</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5S-80.jpg" /><span class="text">小米5s</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5Splus.jpg" /><span class="text">小米5s Plus</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/MIX-80.jpg" /><span class="text">小米MIX</span></a>
									</li>
								</ul>
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5-80.jpg" /><span class="text">小米手机5</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hmn4x80.png" /><span class="text">红米Note 4X</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hmnote4-80.jpg" /><span class="text">红米Note4</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4x_80.png" /><span class="text">红米4x</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4-80.jpg" /><span class="text">红米4</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4A-80.jpg" /><span class="text">红米4A</span></a>
									</li>
								</ul>
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/compare.jpg" /><span class="text">对比手机</span></a>
									</li>
									<li>
										<a href=""><img src="../../static/img/mimobile.jpg" /><span class="text">小米移动电话卡</span></a>
									</li>
								</ul>
							</div>
						</li>
						<li>
							<a href="javascript:void(0);">生活 箱包</a>
							<div class="xuanxiang clear">
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm6_80.png" /><span class="text">小米6</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/5c_80.png" /><span class="text">小米手机5c</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xmNOTE2-80.jpg" /><span class="text">小米Note2</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5S-80.jpg" /><span class="text">小米5s</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5Splus.jpg" /><span class="text">小米5s Plus</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/MIX-80.jpg" /><span class="text">小米MIX</span></a>
									</li>
								</ul>
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/xm5-80.jpg" /><span class="text">小米手机5</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hmn4x80.png" /><span class="text">红米Note 4X</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hmnote4-80.jpg" /><span class="text">红米Note4</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4x_80.png" /><span class="text">红米4x</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4-80.jpg" /><span class="text">红米4</span></a>
									</li>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/hm4A-80.jpg" /><span class="text">红米4A</span></a>
									</li>
								</ul>
								<ul>
									<li>
										<a href="javascript:void(0);"><img src="../../static/img/compare.jpg" /><span class="text">对比手机</span></a>
									</li>
									<li>
										<a href=""><img src="../../static/img/mimobile.jpg" /><span class="text">小米移动电话卡</span></a>
									</li>
								</ul>
							</div>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div class="subBanner">
			<div class="container w">
				<div class="section1 fl clear">
					<ul class="fl">
						<li>
							<a href="javascript:void(0);"><img src="../../static/img/hjh_01.gif" /></a>
						</li>
						<li>
							<a href="javascript:void(0);"><img src="../../static/img/hjh_02.gif" /></a>
						</li>
						<li>
							<a href="javascript:void(0);"><img src="../../static/img/hjh_03.gif" /></a>
						</li>
						<li>
							<a href="javascript:void(0);"><img src="../../static/img/hjh_04.gif" /></a>
						</li>
						<li>
							<a href="javascript:void(0);"><img src="../../static/img/hjh_05.gif" /></a>
						</li>
						<li>
							<a href="javascript:void(0);"><img src="../../static/img/hjh_06.gif" /></a>
						</li>
					</ul>
				</div>
				<div class="section2 fr clear">
					<ul class="fr">
						<li>
							<a href="javascript:void(0);"><img src="../../static/img/xiaomi5.jpg" alt="" /></a>
						</li>
						<li>
							<a href="javascript:void(0);"><img src="../../static/img/hongmi4x.png" alt="" /></a>
						</li>
						<li>
							<a href="javascript:void(0);"><img src="../../static/img/pinghengche.jpg" alt="" /></a>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div class="xmCheap">
			<div class="container w clear">
				<div class="title ">
					<h2>小米闪购</h2>
					<div class="more">
						<a href="#" @click.prevent="switchFn(-1)" class="disabled">&lt;</a>
						<a href="#" @click.prevent="switchFn(+1)" class="disabled">&gt;</a>
					</div>
				</div>
				<div class="cheapBody clear">
					<div class="time fl">
						<div class="field">
							<span>10:00场</span>
						</div>
						<div class="img">
							<img src="../../static/img/flashpurchase.png" />
						</div>
						<div class="end">
							<span>距离结束还有</span>
						</div>
						<div class="timer">
							<div class="hour clock">01</div>
							<div>:</div>
							<div class="minute clock">25</div>
							<div>:</div>
							<div class="second clock">58</div>
						</div>
					</div>
					<div class="productCarousel">
						<ul class="fl" :style="{width:248*len + 'px',transform:`translate(-${activeIndex*100/len}%)`,transition:isResetIndex? '': `transform ${transitionInterval/1000}s`}">
							<li v-for="(item,index) in cheap">
								<div class="one-second" v-show="item.discount == 1">
									一元秒杀
								</div>
								<div class="img">
									<router-link :to='`detail/${item.lid}`'><img :src="item.img" /></router-link>
								</div>
								<div class="title">
									<a href="">{{item.title}}</a>
								</div>
								<div class="subTitle">
									<a href="javascript:void(0);">{{item.subtitle}}</a>
								</div>
								<div class="price">
									<a href="javascript:void(0);">{{item.price}}元<span>{{item.original_price}}元</span></a>

								</div>
							</li>

						</ul>
					</div>
				</div>
			</div>

		</div>
		<div class="banner-box1">
			<div class="container w">
				<a href="javascript:void(0);"><img src="../../static/img/xmad_1539777473169_QyOBh.jpg" /></a>
			</div>
		</div>
		<div class="product">
			<div class="container w">
				<div class="phone">
					<div class="title ">
						<h2>手机</h2>
						<div class="more">
							<router-link to="/products/1" >查看全部</router-link>
							<router-link to="/products/1" ></router-link>
						</div>
					</div>
					<div class="phone-body">
						<div class="left fl big">
							<ul>
								<li>
									<a href="javascript:void(0);"><img src="../../static/img/xmad_15323220713837_GLBVX.jpg" /></a>
								</li>
							</ul>

						</div>
						<div class="right fr ">
							<ul class="big">
								<li v-for="(p,index) in phone" :key='index'>
									<div class="one-second" v-show='p.discount == -1'>
										新品
									</div>
									<div class="one-second" v-show='p.discount < 1&&p.discount>0&&p.discount != null'>
										打{{p.discount* 10}}折
									</div>
									<div class="one-second" v-show='p.discount >1'>
										减{{p.discount}}元
									</div>
									<div class="img">
										<router-link :to='`detail/${p.lid}`'><img :src="p.img" /></router-link>
									</div>
									<div class="title">
										<router-link :to='`detail/${p.lid}`'>{{p.title}}</router-link>
									</div>
									<div class="subTitle">
										<router-link :to='`detail/${p.lid}`'>{{p.subtitle}}</router-link>
									</div>
									<div class="price">
										<router-link :to='`detail/${p.lid}`'>{{p.price}}元
											<span v-show="p.original_price != null">{{p.original_price}}元</span></router-link>
									</div>
								</li>

							</ul>
						</div>
					</div>
				</div>
				<div class="banner-box2">
					<div class="container w">
						<a href="javascript:void(0);"><img src="../../static/img/xmdianshijinqiuhui.jpg" /></a>
					</div>
				</div>
				<div class="jiandian">
					<div class="title ">
						<h2>家电</h2>
						<div class="more">
							<router-link to="/products/2">查看全部</router-link>
							<router-link to="/products/2"></router-link>
						</div>
					</div>
					<div class="jiadian-body">
						<div class="left fl big">
							<ul>
								<li>
									<a href="javascript:void(0);"><img src="../../static/img/mjihdfb.jpg" /></a>
								</li>
								<li>
									<a href="javascript:void(0);"><img src="../../static/img/mjjqr.jpg" /></a>
								</li>
							</ul>

						</div>
						<div class="right fr ">
							<ul class="big">
								<li v-for="(j,index) in jiadian" :key='index'>
									<div class="one-second" v-show='j.discount == -1'>
										新品
									</div>
									<div class="one-second" v-show='j.discount < 1&&j.discount>0&&j.discount != null'>
										打{{j.discount* 10}}折
									</div>
									<div class="one-second" v-show='j.discount >1'>
										减{{j.discount}}元
									</div>
									<div class="img">
										<router-link :to='`detail/${j.lid}`'><img :src="j.img" /></router-link>
									</div>
									<div class="title">
										<router-link :to='`detail/${j.lid}`'>{{j.title}}</router-link>
									</div>
									<div class="subTitle">
										<router-link :to='`detail/${j.lid}`'>{{j.subtitle}}</router-link>
									</div>
									<div class="price">
										<router-link :to='`detail/${j.lid}`'>{{j.price}}元
											<span v-show="j.original_price != null">{{j.original_price}}元</span></router-link>
									</div>
									<div class="comment">
										<p>{{j.comment}}</p>
										<p>{{j.from_user}}</p>
									</div>
								</li>

							</ul>
						</div>
					</div>
				</div>
				<div class="banner-box3">
					<div class="container w">
						<a href="javascript:void(0);"><img src="../../static/img/yashua.jpg" /></a>
					</div>
				</div>
				<div class="zhineng">
					<div class="title ">
						<h2>智能</h2>
						<div class="more">
							<router-link to="/products/4">查看全部</router-link>
							<router-link to="/products/4"></router-link>
						</div>
					</div>
					<div class="zhineng-body">
						<div class="left fl big">
							<ul>
								<li>
									<a href="javascript:void(0);"><img src="../../static/img/zhinengshexiangji.jpg" /></a>
								</li>
								<li>
									<a href="javascript:void(0);"><img src="../../static/img/pinghengche2.jpg" /></a>
								</li>
							</ul>

						</div>
						<div class="right fr ">
							<ul class="big">
								<li v-for="(j,index) in zhineng" :key='index'>
									<div class="one-second" v-show='j.discount == -1'>
										新品
									</div>
									<div class="one-second" v-show='j.discount < 1&&j.discount>0&&j.discount != null'>
										打{{j.discount* 10}}折
									</div>
									<div class="one-second" v-show='j.discount >1'>
										减{{j.discount}}元
									</div>
									<div class="img">
										<router-link :to='`detail/${j.lid}`'><img :src="j.img" /></router-link>
									</div>
									<div class="title">
										<router-link :to='`detail/${j.lid}`'>{{j.title}}</router-link>
									</div>
									<div class="subTitle">
										<router-link :to='`detail/${j.lid}`'>{{j.subtitle}}</router-link>
									</div>
									<div class="price">
										<router-link :to='`detail/${j.lid}`'>{{j.price}}元
											<span v-show="j.original_price != null">{{j.original_price}}元</span></router-link>
									</div>
									<div class="comment">
										<p>{{j.comment}}</p>
										<p>{{j.from_user}}</p>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="banner-box4">
					<div class="container w">
						<a href="javascript:void(0);"><img src="../../static/img/bjbbanner3.jpg" /></a>
					</div>
				</div>
				<div class="dapei">
					<div class="title ">
						<h2>搭配</h2>
						<div class="more">
							<router-link to="/products/5">查看全部</router-link>
							<router-link to="/products/5"></router-link>
						</div>
					</div>
					<div class="dapei-body">
						<div class="left fl big">
							<ul>
								<li>
									<a href="javascript:void(0);"><img src="../../static/img/zhinengshexiangji.jpg" /></a>
								</li>
								<li>
									<a href="javascript:void(0);"><img src="../../static/img/pinghengche2.jpg" /></a>
								</li>
							</ul>

						</div>
						<div class="right fr ">
							<ul class="big">
								<li v-for="(j,index) in dapei" :key='index'>
									<div class="one-second" v-show='j.discount == -1'>
										新品
									</div>
									<div class="one-second" v-show='j.discount < 1&&j.discount>0&&j.discount != null'>
										打{{j.discount* 10}}折
									</div>
									<div class="one-second" v-show='j.discount >1'>
										减{{j.discount}}元
									</div>
									<div class="img">
										<router-link :to='`detail/${j.lid}`'><img :src="j.img" /></router-link>
									</div>
									<div class="title">
										<router-link :to='`detail/${j.lid}`'>{{j.title}}</router-link>
									</div>
									<div class="subTitle">
										<router-link :to='`detail/${j.lid}`'>{{j.subtitle}}</router-link>
									</div>
									<div class="price">
										<router-link :to='`detail/${j.lid}`'>{{j.price}}元
											<span v-show="j.original_price != null">{{j.original_price}}元</span></router-link>
									</div>
									<div class="comment">
										<p>{{j.comment}}</p>
										<p>{{j.from_user}}</p>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="tuijian">
					<div class="container w clear">
						<div class="title ">
							<h2>为你推荐</h2>
							<div class="more">
								
							</div>
						</div>
						<div class="tuijianBody clear">

							<div class="productCarousel">
								<ul class="fl big" style="transform: translateX(-1000px);">
									<li v-for="(t,index) in cheap" :key='index'>

										<div class="img">
											<router-link :to="`/detail/${t.lid}`"><img :src="t.img" /></router-link>
										</div>
										<div class="title">
											<router-link :to="`/detail/${t.lid}`">{{t.title}}</router-link>
										</div>
										<div class="subTitle">
											<router-link :to="`/detail/${t.lid}`">{{t.subtitle}}</router-link>
										</div>
										<div class="price">
											<router-link :to="`/detail/${t.lid}`">{{t.price}}元 <span>{{t.original_price}}元</span></router-link>

										</div>
									</li>

								</ul>
							</div>
						</div>
					</div>

				</div>
				<div class="reping">
					<div class="container w clear">
						<div class="title ">
							<h2>热评产品</h2>

						</div>
						<div class="repingBody clear">
							<div class="productCarousel">
								<ul class="fl big">
									<li>
										<div class="img">
											<a href="javascript:void(0);"><img src="../../static/img/repingdianfanbao.jpg" /></a>
										</div>
										<div class="title">
											<a href="">包装很让人感动，式样也很可爱，做出的饭全家人都爱吃，超爱五星！手机控制还是不太熟练，最主要是没有连接...</a>
										</div>
										<div class="subTitle">
											<a href="javascript:void(0);"> 来自于 HZG 的评价 </a>
										</div>
										<div class="price">
											<a href="javascript:void(0);"><span>米家电饭煲 </span>&nbsp;999元</a>

										</div>
									</li>
									<li>

										<div class="img">
											<a href="javascript:void(0);"><img src="../../static/img/xmkqjhq.jpg" /></a>
										</div>
										<div class="title">
											<a href="">外形简洁大方，大爱小米！全家人都在用小米的产品，真心不错，最主要的是性价比高。附图，给客服妹子一个大...</a>
										</div>
										<div class="subTitle">
											<a href="javascript:void(0);"> 来自于 酸小妞～！ 的评价 </a>
										</div>
										<div class="price">
											<a href="javascript:void(0);"><span>米家空气净化器</span>&nbsp;449元</a>

										</div>
									</li>
									<li>

										<div class="img">
											<a href="javascript:void(0);"><img src="../../static/img/xmyx.jpg" /></a>
										</div>
										<div class="title">
											<a href="">超级喜欢！小巧玲珑！音质完美！不知道为什么！只要是小米出的东西我都喜欢！那倒是因为那一句？？小米为发...</a>
										</div>
										<div class="subTitle">
											<a href="javascript:void(0);"> 来自于 田密 的评价 </a>
										</div>
										<div class="price">
											<a href="javascript:void(0);"><span>小米随身蓝牙音箱 </span>&nbsp;69元</a>

										</div>
									</li>
									<li>

										<div class="img">
											<a href="javascript:void(0);"><img src="../../static/img/mtdh.jpg" /></a>
										</div>
										<div class="title">
											<a href="">非常好用，孩子使用防止沉迷于电话影响学习。做工很好，定位基本准确，通话清晰。如果加入时间显示就更完美...</a>
										</div>
										<div class="subTitle">
											<a href="javascript:void(0);"> 来自于 178576259 的评价 </a>
										</div>
										<div class="price">
											<a href="javascript:void(0);"><span>米兔定位电话 </span>&nbsp;169元</a>

										</div>
									</li>

								</ul>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
		<!---------窗口右侧固定栏窗口 & 返回顶部---------->
		<div class="right-bar">
			<div class="bar-lg">
				<div class="bar-top">
					<ul>
						<li>
							<a href="javascript:void(0);">
								<div class="bar-img ">

								</div>
								<p>个人中心</p>
							</a>
						</li>
						<li>
							<a href="javascript:void(0);">
								<div class="bar-img ">

								</div>
								<p>联系客服</p>
							</a>
						</li>
						<li>
							<a href="javascript:void(0);">
								<div class="bar-img ">

								</div>
								<p>购物车</p>
							</a>
						</li>
					</ul>
					<div class="totop">
						<a href="">
							<div class="totop-img">

							</div>
							<p>
								<a href="javascript:scroll(0,0)"></a>返回顶部</p>
						</a>
					</div>
				</div>
			</div>
			<div class="bar-sm">
				<ul>
					<li>
						<a href="javascript:void(0);"><img src="../../static/img/right-1.png" alt="个人中心" /><img src="../../static/img/right-1-hover.png" alt="个人中心" /></a>
					</li>
					<li>
						<a href="javascript:void(0);"><img src="../../static/img/right-2.png" alt="联系客服" /><img src="../../static/img/right-2-hover.png" alt="联系客服" /></a>
					</li>
					<li>
						<a href="javascript:void(0);"><img src="../../static/img/right-3.png" alt="购物车" /><img src="../../static/img/right-3-hover.png" alt="购物车" /></a>
					</li>
					<li class="totop">
						<a href="javascript:scroll(0,0)"><img src="../../static/img/totop.png" alt="返回顶部" /><img src="../../static/img/totop_hover.png" alt="返回顶部" /></a>
					</li>
				</ul>
			</div>
		</div>
	</div>

</template>

<script>
	export default {
		data: function() {
			return {
				imgArr: [],
				mark: 0,
				timer: "",
				cheap: [],
				phone: '',
				jiadian: '',
				zhineng: '',
				dapei: '',
				activeIndex: 4,
				timer: null,
				isTransitioning: false,
				transitionInterval: 500,
				isResetIndex: false,
				len:0
			}

		},
		created() {
			this.play();
			this.toTop();
			this.getCarousel();
			this.getCheap();
			this.getPhone();
			this.getJiadian();
			this.getZhineng();
			this.getDapei();
			
			//this.imgsComputed()
		},
		methods: {
			switchFn(i) {
				//console.log(this.len)
				if(this.isTransitioning) {
					return
				}
				else if(i == 1) {
					this.activeIndex += 4
				}
				else if(i == -1) {
					this.activeIndex -= 4
				}

			},
			getCarousel() {
				this.axios.get('/index/getCarousel')
					.then(res => {
						this.imgArr = res.data
						//console.log(res.data)
					})
			},
			getCheap() {
				this.axios.get('/index/getCheap')
					.then(res => {
						this.cheap = res.data
						for(var i = 0; i < 4; i++) {
							this.cheap.push(this.cheap[i])
							this.cheap.unshift(this.cheap[this.cheap.length - 1 - i])
						}
						this.len = this.cheap.length
					})
			},
			getPhone() {
				this.axios.get('/index/getPhone')
					.then(res => {
						this.phone = res.data
					})
			},
			getJiadian() {
				this.axios.get('/index/getJiadian')
					.then(res => {
						this.jiadian = res.data
					})
			},
			getZhineng() {
				this.axios.get('/index/getZhineng')
					.then(res => {
						this.zhineng = res.data
					})
			},
			getDapei() {
				this.axios.get('/index/getDapei')
					.then(res => {
						this.dapei = res.data
					})
			},
			autoplay() {
				this.mark++;
				if(this.mark == this.imgArr.length)
					this.mark = 0;
			},
			play() {
				this.timer = setInterval(this.autoplay, 3000)
			},
			clearauto() {
				clearInterval(this.timer)
			},
			clickleft() {
				if(this.mark == 0) {
					this.mark = this.imgArr.length - 1;
				}
				else {
					this.mark--;
				}

			},
			clickright() {
				if(this.mark == this.imgArr.length - 1) {
					this.mark = 0;
				}
				else {
					this.mark++;
				}

			},
			setIndex(mark) {
				this.mark = mark;
			},
			mouseenter() {
				this.clearauto();
			},
			mouseleave() {
				this.play();
			},
			toTop() {
				$(window)
					.scroll(function() {
						var scrollValue = $(window)
							.scrollTop();
						scrollValue > 500 ? $('[class=totop]')
							.fadeIn() : $('[class=totop]')
							.fadeOut();
					});
			},
			
		},
		watch: {
			activeIndex(newActiveIndex, oldActiveIndex) {
				if((newActiveIndex === 4 && oldActiveIndex === (this.len - 4)) || (oldActiveIndex === 0 && newActiveIndex === this.len - 8)) {
					this.isResetIndex = true
					return
				}
				this.isResetIndex = false
				this.isTransitioning = true
				setTimeout(() => {
					if(this.activeIndex === 0) {
						this.activeIndex = this.len - 8
					}
					else if(this.activeIndex === (this.len - 4)) {
						this.activeIndex = 4
					}
					this.isTransitioning = false
				}, this.transitionInterval)
			}
		}
	}
</script>

<style scoped>
	/*-----------------start banner-------------*/
	
	.banner {
		height: 460px;
	}
	
	.banner .container {
		position: relative;
		height: 460px;
	}
	
	.banner .carrousel .bannerImg img {
		width: 100%;
		position: absolute;
		top: 0;
		left: 0;
		/*opacity: 0;*/
		transition: all .3s;
	}
	/*.banner .carrousel .bannerImg .active {
	opacity: 1;
}*/
	
	.banner .carrousel .bannerList ul {
		z-index: 100;
		position: absolute;
		right: 15px;
		bottom: 15px;
	}
	
	.banner .carrousel .bannerList ul li {
		display: block;
		width: 5px;
		height: 5px;
		margin: 5px;
		border-radius: 50%;
		float: left;
		border: 2px solid #999;
		background: rgba(0, 0, 0, .3);
		cursor: pointer;
		transition: all .3s;
	}
	
	.banner .carrousel .bannerList ul li:hover {
		background: #eee;
	}
	
	.banner .carrousel .bannerList .active {
		background: #eee;
	}
	
	.banner .carrousel .prev,
	.banner .carrousel .next {
		width: 40px;
		height: 70px;
		position: absolute;
		z-index: 100;
		cursor: pointer;
	}
	
	.banner .carrousel .next:hover {
		background: url(../../static/img/icon-slides.png) no-repeat -43px 50%;
	}
	
	.banner .carrousel .prev:hover {
		background: url(../../static/img/icon-slides.png) no-repeat 0px 50%;
	}
	
	.banner .carrousel .prev {
		background: url(../../static/img/icon-slides.png) no-repeat -84px 50%;
		position: absolute;
		left: 234px;
		top: 195px;
	}
	
	.banner .carrousel .next {
		background: url(../../static/img/icon-slides.png) no-repeat -125px 50%;
		right: 0px;
		top: 195px;
	}
	
	.banner .list {
		width: 234px;
		height: 460px;
		background: rgba(0, 0, 0, .6);
		position: absolute;
		top: 0;
		left: 0;
	}
	
	.banner .list>ul {
		width: 234px;
		height: 420px;
		padding-top: 20px;
		padding-bottom: 20px;
		padding: 20px 0px;
		font-size: 14px;
		position: relative;
	}
	
	.banner .list>ul li {
		float: left;
		width: 234px;
		height: 42px;
		line-height: 42px;
	}
	
	.banner .list>ul>li>a {
		display: block;
		width: 204px;
		height: 42px;
		line-height: 42px;
		padding-left: 30px;
		color: #fff;
		background: url("../../static/img/arrow-right(1).png") no-repeat 204px 10px;
		transition: all .2s;
	}
	
	.banner .list>ul>li>a:hover {
		background: #FF6700 url("../../static/img/arrow-right(1).png") no-repeat 204px 10px;
	}
	
	.banner .list>ul>li .xuanxiang {
		height: 460px;
		line-height: 460px;
		/*width: 800px;*/
		white-space: nowrap;
		background: #fff;
		position: absolute;
		left: 234px;
		top: 0;
		z-index: 100;
		box-shadow: 2px 5px 10px 2px #999;
		display: none;
	}
	
	.banner .list ul>li:hover .xuanxiang {
		display: flex;
	}
	
	.banner .list>ul>li>.xuanxiang ul {
		height: 460px;
		width: 234px;
		font-size: 14px;
		float: left;
	}
	
	.banner .list>ul>li>.xuanxiang ul li {
		margin-top: 30px;
	}
	
	.banner .list>ul>li>.xuanxiang ul li a {
		display: block;
		width: 234px;
		height: 42px;
		line-height: 42px;
		padding-left: 30px;
	}
	
	.banner .list>ul>li>.xuanxiang ul li a img {
		vertical-align: middle;
	}
	
	.banner .list>ul>li>.xuanxiang ul li a span.text {
		margin-left: 40px;
		transition: all .2s;
	}
	
	.banner .list>ul>li>.xuanxiang ul li a:hover {
		color: #FF6700;
	}
	/*-----------------end banner-------------*/
	/*------------------start subBanner-------*/
	
	.subBanner {
		height: 170px;
		margin-bottom: 16px;
	}
	
	.subBanner .container {
		height: 170px;
		margin-top: 14px;
	}
	
	.subBanner .section1 {
		height: 170px;
		width: 234px;
	}
	
	.subBanner .section1 ul li {
		float: left;
	}
	
	.subBanner .section1 ul li a {
		display: block;
		height: 85px;
	}
	
	.subBanner .section2 {
		height: 170px;
		width: 992px;
	}
	
	.subBanner .section2 ul li {
		float: right;
		width: 316px;
		height: 170px;
		margin-left: 14px;
	}
	
	.subBanner .section2 ul li a {
		display: block;
	}
	
	.subBanner .section2 ul li img {
		width: 316px;
		height: 170px;
	}
	/*------------------end subBanner-------*/
	/*------------------start xmCheap--------*/
	
	.xmCheap {
		height: 438px;
	}
	
	.xmCheap .container {
		height: 438px;
		/*border:1px solid red;*/
		font-size: 15px;
	}
	
	.xmCheap .container .title {
		height: 58px;
		line-height: 58px;
		position: relative;
	}
	
	.xmCheap .container .title h2 {
		font-size: 22px;
		font-weight: 200;
		text-overflow: ellipsis;
	}
	
	.xmCheap .container .title .more {
		width: 70px;
		height: 25px;
		position: absolute;
		right: 0px;
		bottom: 5px;
		/*border: 1px solid green;*/
	}
	
	.xmCheap .container .title .more a {
		display: block;
		float: left;
		height: 16px;
		line-height: 16px;
		width: 23px;
		padding: 3px 5px;
		text-align: center;
		color: #e0e0e0;
		border: 1px solid #e0e0e0;
	}
	
	.xmCheap .container .title .more .disabled {
		color: #b0b0b0;
		border: 1px solid #b0b0b0;
	}
	
	.xmCheap .container .cheapBody {
		height: 340px;
		display: flex;
	}
	
	.xmCheap .container .cheapBody .time {
		height: 300px;
		padding-top: 39px;
		margin-right: 14px;
		width: 234px;
		text-align: center;
		background: #F1EDED;
		border-top: 1px solid red;
	}
	
	.xmCheap .container .cheapBody .time .field {
		height: 31px;
		line-height: 31px;
		width: 234px;
		padding-top: 15px;
		font-size: 21px;
		color: #ef3a3b;
	}
	
	.xmCheap .container .cheapBody .time .img {
		margin: 25px 0px;
	}
	
	.xmCheap .container .cheapBody .time .end {
		color: rgba(0, 0, 0, .54);
	}
	
	.xmCheap .container .cheapBody .time .timer {
		width: 168px;
		height: 46px;
		line-height: 46px;
		margin: 0 auto;
		margin-top: 28px;
	}
	
	.xmCheap .container .cheapBody .time .timer div {
		float: left;
		font-size: 24px;
		color: #fff;
		font-weight: bold;
	}
	
	.xmCheap .container .cheapBody .time .timer .clock {
		background: #605751;
		width: 46px;
		height: 46px;
	}
	
	.xmCheap .container .cheapBody .time .timer div:not(.clock) {
		width: 15px;
		color: #605751;
	}
	
	.xmCheap .container .cheapBody .productCarousel {
		overflow: hidden;
	}
	
	.xmCheap .container .cheapBody .productCarousel ul {
		display: flex;
		flex-wrap: nowrap;
	}
	
	.xmCheap .container .cheapBody .productCarousel ul li {
		height: 300px;
		padding-top: 39px;
		margin-right: 14px;
		width: 234px;
		text-align: center;
		cursor: pointer;
		background: rgba(0, 0, 0, 0.02);
		border-top: 1px solid orange;
		position: relative;
	}
	
	.xmCheap .container .cheapBody .productCarousel ul li .one-second {
		background: red;
		color: #fff;
		width: 64px;
		height: 20px;
		line-height: 20px;
		position: absolute;
		top: 0px;
		left: 85px;
		font-size: 14px;
	}
	
	.xmCheap .container .cheapBody .productCarousel ul li .img {
		width: 160px;
		height: 166px;
		margin: 0px auto 22px;
	}
	
	.xmCheap .container .cheapBody .productCarousel ul li .img img {
		width: 100%;
	}
	
	.xmCheap .container .cheapBody .productCarousel ul li .title {
		width: 194px;
		height: 40px;
		margin: 0 auto 3px;
		font-size: 14px;
		font-weight: 400;
		text-overflow: ellipsis;
	}
	
	.xmCheap .container .cheapBody .productCarousel ul li .title a {
		color: #212121;
		text-overflow: ellipsis;
	}
	
	.xmCheap .container .cheapBody .productCarousel ul li .subTitle {
		width: 194px;
		height: 18px;
		margin: 0 auto 12px;
		font-size: 12px;
		text-overflow: ellipsis;
	}
	
	.xmCheap .container .cheapBody .productCarousel ul li .subTitle a {
		color: #b0b0b0;
		text-overflow: ellipsis;
	}
	
	.xmCheap .container .cheapBody .productCarousel ul li .price a {
		color: #ff6709;
	}
	
	.xmCheap .container .cheapBody .productCarousel ul li .price a span {
		color: #b0b0b0;
		text-decoration: line-through;
	}
	/*------------------end xmCheap--------*/
	/*------------------start banner-box1--------*/
	
	.banner-box1 .container {
		margin: 2px auto 42px;
	}
	
	.banner-box1 .container img {
		width: 100%;
	}
	/*------------------end banner-box1--------*/
	
	.product {
		background: #F5F5F5;
	}
	
	.phone .title {
		height: 58px;
		line-height: 58px;
		position: relative;
	}
	
	.phone .title h2 {
		font-size: 22px;
		font-weight: 200;
		text-overflow: ellipsis;
	}
	
	.phone .title .more {
		width: 92px;
		height: 58px;
		line-height: 58px;
		position: absolute;
		right: 0px;
		bottom: 0px;
		/*border: 1px solid green;*/
	}
	
	.phone .title .more a {
		font-size: 16px;
		color: #424242;
		display: block;
		float: left;
		transition: all .3s;
	}
	
	.phone .title .more a:last-child {
		background: #b0b0b0 url("../../static/img/arrow-right(1).png") no-repeat 6px 2px;
		color: #fff;
		font-weight: bold;
		width: 20px;
		height: 20px;
		margin-top: 18px;
		margin-left: 5px;
		border-radius: 50%;
	}
	
	.phone .title .more:hover a {
		color: #FF6700;
	}
	
	.phone .title .more:hover a:last-child {
		background: #FF6700 url("../../static/img/arrow-right(1).png") no-repeat 6px 2px;
	}
	
	.phone .phone-body {
		height: 628px;
		/*background: #605751;*/
	}
	
	.phone .phone-body .left {
		width: 234px;
		height: 628px;
	}
	
	.phone .phone-body .left img {
		width: 100%;
	}
	
	.phone .phone-body .right {
		width: 992px;
		height: 628px;
	}
	
	.phone .phone-body .right ul {
		display: flex;
		flex-wrap: wrap;
	}
	
	.phone .phone-body .right ul li {
		height: 260px;
		padding: 20px 0px;
		margin: 0 0 14px 14px;
		width: 234px;
		text-align: center;
		cursor: pointer;
		background: #fff;
		position: relative;
	}
	
	.phone .phone-body .right ul li .one-second {
		background: red;
		color: #fff;
		width: 64px;
		height: 20px;
		line-height: 20px;
		position: absolute;
		top: 0px;
		left: 85px;
		font-size: 14px;
	}
	
	.phone .phone-body .right ul li:first-child .one-second,
	.phone .phone-body .right ul li:nth-child(2) .one-second {
		background: #83C44E;
	}
	
	.phone .phone-body .right ul li .img {
		width: 160px;
		height: 166px;
		margin: 0px auto 0px;
	}
	
	.phone .phone-body .right ul li .img a {
		display: block;
	}
	
	.phone .phone-body .right ul li .img img {
		width: 100%;
	}
	
	.phone .phone-body .right ul li .title {
		width: 214px;
		height: 40px;
		margin: 0 auto 3px;
		font-size: 14px;
		font-weight: 400;
		text-overflow: ellipsis;
	}
	
	.phone .phone-body .right ul li .title a {
		color: #212121;
		text-overflow: ellipsis;
	}
	
	.phone .phone-body .right ul li .subTitle {
		width: 194px;
		height: 18px;
		margin: 0 auto 12px;
		font-size: 12px;
		text-overflow: ellipsis;
	}
	
	.phone .phone-body .right ul li .subTitle a {
		color: #b0b0b0;
		text-overflow: ellipsis;
	}
	
	.phone .phone-body .right ul li .price a {
		color: #ff6709;
	}
	
	.phone .phone-body .right ul li .price a span {
		color: #b0b0b0;
		text-decoration: line-through;
	}
	/*------------------start banner-box2--------*/
	
	.banner-box2 .container {
		margin: 28px auto 22px;
	}
	
	.banner-box2 .container img {
		width: 100%;
	}
	/*------------------end banner-box2--------*/
	/*-----------------start jiadian-----------*/
	
	.jiandian .title {
		height: 58px;
		line-height: 58px;
		position: relative;
	}
	
	.jiandian .title h2 {
		font-size: 22px;
		font-weight: 200;
		text-overflow: ellipsis;
	}
	
	.jiandian .title .more {
		width: 92px;
		height: 58px;
		line-height: 58px;
		position: absolute;
		right: 0px;
		bottom: 0px;
		/*border: 1px solid green;*/
	}
	
	.jiandian .title .more a {
		font-size: 16px;
		color: #424242;
		display: block;
		float: left;
		transition: all .3s;
	}
	
	.jiandian .title .more a:last-child {
		background: #b0b0b0 url("../../static/img/arrow-right(1).png") no-repeat 6px 2px;
		color: #fff;
		font-weight: bold;
		width: 20px;
		height: 20px;
		margin-top: 18px;
		margin-left: 5px;
		border-radius: 50%;
	}
	
	.jiandian .title .more:hover a {
		color: #FF6700;
	}
	
	.jiandian .title .more:hover a:last-child {
		background: #FF6700 url("../../static/img/arrow-right(1).png") no-repeat 6px 2px;
	}
	
	.jiandian .jiadian-body {
		height: 628px;
		/*background: #605751;*/
	}
	
	.jiandian .jiadian-body .left {
		width: 234px;
		height: 628px;
	}
	
	.jiandian .jiadian-body .left img {
		width: 100%;
	}
	
	.jiandian .jiadian-body .right {
		width: 992px;
		height: 628px;
	}
	
	.jiandian .jiadian-body .right ul {
		display: flex;
		flex-wrap: wrap;
	}
	
	.jiandian .jiadian-body .right ul li {
		height: 260px;
		padding: 20px 0px;
		margin: 0 0 14px 14px;
		width: 234px;
		text-align: center;
		cursor: pointer;
		background: #fff;
		position: relative;
	}
	
	.jiandian .jiadian-body .right ul li .one-second {
		background: red;
		color: #fff;
		width: 64px;
		height: 20px;
		line-height: 20px;
		position: absolute;
		top: 0px;
		left: 85px;
		font-size: 14px;
	}
	
	.jiandian .jiadian-body .right ul li:first-child .one-second,
	.jiandian .jiadian-body .right ul li:nth-child(2) .one-second {
		background: #83C44E;
	}
	
	.jiandian .jiadian-body .right ul li .img {
		width: 160px;
		height: 166px;
		margin: 0px auto 0px;
	}
	
	.jiandian .jiadian-body .right ul li .img a {
		display: block;
	}
	
	.jiandian .jiadian-body .right ul li .img img {
		width: 100%;
	}
	
	.jiandian .jiadian-body .right ul li .title {
		width: 214px;
		height: 40px;
		margin: 0 auto 3px;
		font-size: 14px;
		font-weight: 400;
		text-overflow: ellipsis;
	}
	
	.jiandian .jiadian-body .right ul li .title a {
		color: #212121;
		text-overflow: ellipsis;
	}
	
	.jiandian .jiadian-body .right ul li .subTitle {
		width: 194px;
		height: 18px;
		margin: 0 auto 12px;
		font-size: 12px;
		text-overflow: ellipsis;
	}
	
	.jiandian .jiadian-body .right ul li .subTitle a {
		color: #b0b0b0;
		text-overflow: ellipsis;
	}
	
	.jiandian .jiadian-body .right ul li .price a {
		color: #ff6709;
	}
	
	.jiandian .jiadian-body .right ul li .price a span {
		color: #b0b0b0;
		text-decoration: line-through;
	}
	
	.jiandian .jiadian-body .right ul li .comment {
		position: absolute;
		bottom: 0px;
		width: 234px;
		height: 0px;
		background: #FF6700;
		transition: all .3s;
		opacity: 0;
	}
	
	.jiandian .jiadian-body .right ul li:hover .comment {
		height: 75px;
		opacity: 1;
	}
	
	.jiandian .jiadian-body .right ul li .comment p:first-child {
		color: #fff;
		font-size: 10px;
		margin-top: 10px;
	}
	
	.jiandian .jiadian-body .right ul li .comment p:nth-child(2) {
		color: #eee;
		font-size: 8px;
		margin-top: 10px;
	}
	/*-----------------end jiadian-----------*/
	/*------------------start banner-box3--------*/
	
	.banner-box3 .container {
		margin: 28px auto 22px;
	}
	
	.banner-box3 .container img {
		width: 100%;
	}
	/*------------------end banner-box3--------*/
	/*------------------start zhineng----------*/
	
	.zhineng .title {
		height: 58px;
		line-height: 58px;
		position: relative;
	}
	
	.zhineng .title h2 {
		font-size: 22px;
		font-weight: 200;
		text-overflow: ellipsis;
	}
	
	.zhineng .title .more {
		width: 92px;
		height: 58px;
		line-height: 58px;
		position: absolute;
		right: 0px;
		bottom: 0px;
		/*border: 1px solid green;*/
	}
	
	.zhineng .title .more a {
		font-size: 16px;
		color: #424242;
		display: block;
		float: left;
		transition: all .3s;
	}
	
	.zhineng .title .more a:last-child {
		background: #b0b0b0 url("../../static/img/arrow-right(1).png") no-repeat 6px 2px;
		color: #fff;
		font-weight: bold;
		width: 20px;
		height: 20px;
		margin-top: 18px;
		margin-left: 5px;
		border-radius: 50%;
	}
	
	.zhineng .title .more:hover a {
		color: #FF6700;
	}
	
	.zhineng .title .more:hover a:last-child {
		background: #FF6700 url("../../static/img/arrow-right(1).png") no-repeat 6px 2px;
	}
	
	.zhineng .zhineng-body {
		height: 628px;
		/*background: #605751;*/
	}
	
	.zhineng .zhineng-body .left {
		width: 234px;
		height: 628px;
	}
	
	.zhineng .zhineng-body .left img {
		width: 100%;
	}
	
	.zhineng .zhineng-body .right {
		width: 992px;
		height: 628px;
	}
	
	.zhineng .zhineng-body .right ul {
		display: flex;
		flex-wrap: wrap;
	}
	
	.zhineng .zhineng-body .right ul li {
		height: 260px;
		padding: 20px 0px;
		margin: 0 0 14px 14px;
		width: 234px;
		text-align: center;
		cursor: pointer;
		background: #fff;
		position: relative;
	}
	
	.zhineng .zhineng-body .right ul li .one-second {
		background: red;
		color: #fff;
		width: 64px;
		height: 20px;
		line-height: 20px;
		position: absolute;
		top: 0px;
		left: 85px;
		font-size: 14px;
	}
	
	.zhineng .zhineng-body .right ul li:first-child .one-second,
	.zhineng .zhineng-body .right ul li:nth-child(2) .one-second {
		background: #83C44E;
	}
	
	.zhineng .zhineng-body .right ul li .img {
		width: 160px;
		height: 166px;
		margin: 0px auto 0px;
	}
	
	.zhineng .zhineng-body .right ul li .img a {
		display: block;
	}
	
	.zhineng .zhineng-body .right ul li .img img {
		width: 100%;
	}
	
	.zhineng .zhineng-body .right ul li .title {
		width: 214px;
		height: 40px;
		margin: 0 auto 3px;
		font-size: 14px;
		font-weight: 400;
		text-overflow: ellipsis;
	}
	
	.zhineng .zhineng-body .right ul li .title a {
		color: #212121;
		text-overflow: ellipsis;
	}
	
	.zhineng .zhineng-body .right ul li .subTitle {
		width: 194px;
		height: 18px;
		margin: 0 auto 12px;
		font-size: 12px;
		text-overflow: ellipsis;
	}
	
	.zhineng .zhineng-body .right ul li .subTitle a {
		color: #b0b0b0;
		text-overflow: ellipsis;
	}
	
	.zhineng .zhineng-body .right ul li .price a {
		color: #ff6709;
	}
	
	.zhineng .zhineng-body .right ul li .price a span {
		color: #b0b0b0;
		text-decoration: line-through;
	}
	
	.zhineng .zhineng-body .right ul li .comment {
		position: absolute;
		bottom: 0px;
		width: 234px;
		height: 0px;
		background: #FF6700;
		transition: all .3s;
		opacity: 0;
	}
	
	.zhineng .zhineng-body .right ul li:hover .comment {
		height: 75px;
		opacity: 1;
	}
	
	.zhineng .zhineng-body .right ul li .comment p:first-child {
		color: #fff;
		font-size: 10px;
		margin-top: 10px;
	}
	
	.zhineng .zhineng-body .right ul li .comment p:nth-child(2) {
		color: #eee;
		font-size: 8px;
		margin-top: 10px;
	}
	/*------------------end zhineng----------*/
	/*------------------start banner-box3--------*/
	
	.banner-box4 .container {
		margin: 28px auto 22px;
	}
	
	.banner-box4 .container img {
		width: 100%;
	}
	/*------------------end banner-box3--------*/
	/*------------------start dapei----------*/
	
	.dapei .title {
		height: 58px;
		line-height: 58px;
		position: relative;
	}
	
	.dapei .title h2 {
		font-size: 22px;
		font-weight: 200;
		text-overflow: ellipsis;
	}
	
	.dapei .title .more {
		width: 92px;
		height: 58px;
		line-height: 58px;
		position: absolute;
		right: 0px;
		bottom: 0px;
		/*border: 1px solid green;*/
	}
	
	.dapei .title .more a {
		font-size: 16px;
		color: #424242;
		display: block;
		float: left;
		transition: all .3s;
	}
	
	.dapei .title .more a:last-child {
		background: #b0b0b0 url("../../static/img/arrow-right(1).png") no-repeat 6px 2px;
		color: #fff;
		font-weight: bold;
		width: 20px;
		height: 20px;
		margin-top: 18px;
		margin-left: 5px;
		border-radius: 50%;
	}
	
	.dapei .title .more:hover a {
		color: #FF6700;
	}
	
	.dapei .title .more:hover a:last-child {
		background: #FF6700 url("../../static/img/arrow-right(1).png") no-repeat 6px 2px;
	}
	
	.dapei .dapei-body {
		height: 628px;
		/*background: #605751;*/
	}
	
	.dapei .dapei-body .left {
		width: 234px;
		height: 628px;
	}
	
	.dapei .dapei-body .left img {
		width: 100%;
	}
	
	.dapei .dapei-body .right {
		width: 992px;
		height: 628px;
	}
	
	.dapei .dapei-body .right ul {
		display: flex;
		flex-wrap: wrap;
	}
	
	.dapei .dapei-body .right ul li {
		height: 260px;
		padding: 20px 0px;
		margin: 0 0 14px 14px;
		width: 234px;
		text-align: center;
		cursor: pointer;
		background: #fff;
		position: relative;
	}
	
	.dapei .dapei-body .right ul li .one-second {
		background: red;
		color: #fff;
		width: 64px;
		height: 20px;
		line-height: 20px;
		position: absolute;
		top: 0px;
		left: 85px;
		font-size: 14px;
	}
	
	.dapei .dapei-body .right ul li:first-child .one-second,
	.dapei .dapei-body .right ul li:nth-child(2) .one-second {
		background: #83C44E;
	}
	
	.dapei .dapei-body .right ul li .img {
		width: 160px;
		height: 166px;
		margin: 0px auto 0px;
	}
	
	.dapei .dapei-body .right ul li .img a {
		display: block;
	}
	
	.dapei .dapei-body .right ul li .img img {
		width: 100%;
	}
	
	.dapei .dapei-body .right ul li .title {
		width: 214px;
		height: 40px;
		margin: 0 auto 3px;
		font-size: 14px;
		font-weight: 400;
		text-overflow: ellipsis;
	}
	
	.dapei .dapei-body .right ul li .title a {
		color: #212121;
		text-overflow: ellipsis;
	}
	
	.dapei .dapei-body .right ul li .subTitle {
		width: 194px;
		height: 18px;
		margin: 0 auto 12px;
		font-size: 12px;
		text-overflow: ellipsis;
	}
	
	.dapei .dapei-body .right ul li .subTitle a {
		color: #b0b0b0;
		text-overflow: ellipsis;
	}
	
	.dapei .dapei-body .right ul li .price a {
		color: #ff6709;
	}
	
	.dapei .dapei-body .right ul li .price a span {
		color: #b0b0b0;
		text-decoration: line-through;
	}
	
	.dapei .dapei-body .right ul li .comment {
		position: absolute;
		bottom: 0px;
		width: 234px;
		height: 0px;
		background: #FF6700;
		transition: all .3s;
		opacity: 0;
	}
	
	.dapei .dapei-body .right ul li:hover .comment {
		height: 75px;
		opacity: 1;
	}
	
	.dapei .dapei-body .right ul li .comment p:first-child {
		color: #fff;
		font-size: 10px;
		margin-top: 10px;
	}
	
	.dapei .dapei-body .right ul li .comment p:nth-child(2) {
		color: #eee;
		font-size: 8px;
		margin-top: 10px;
	}
	/*------------------end dapei----------*/
	/*------------------start tuijian--------*/
	
	.tuijian {
		height: 438px;
	}
	
	.tuijian .container {
		height: 438px;
		/*border:1px solid red;*/
		font-size: 15px;
	}
	
	.tuijian .container .title {
		height: 58px;
		line-height: 58px;
		position: relative;
	}
	
	.tuijian .container .title h2 {
		font-size: 22px;
		font-weight: 200;
		text-overflow: ellipsis;
	}
	
	.tuijian .container .title .more {
		width: 70px;
		height: 25px;
		position: absolute;
		right: 0px;
		bottom: 5px;
		/*border: 1px solid green;*/
	}
	
	.tuijian .container .title .more a {
		display: block;
		float: left;
		height: 16px;
		line-height: 16px;
		width: 23px;
		padding: 3px 5px;
		text-align: center;
		color: #e0e0e0;
		border: 1px solid #e0e0e0;
	}
	
	.tuijian .container .title .more .disabled {
		color: #b0b0b0;
		border: 1px solid #b0b0b0;
	}
	
	.tuijian .container .tuijianBody {
		height: 340px;
		display: flex;
	}
	
	.tuijian .container .tuijianBody .productCarousel {
		overflow: hidden;
	}
	
	.tuijian .container .tuijianBody .productCarousel ul {
		display: flex;
		flex-wrap: nowrap;
	}
	
	.tuijian .container .tuijianBody .productCarousel ul li {
		height: 300px;
		padding-top: 39px;
		margin-right: 14px;
		width: 234px;
		text-align: center;
		cursor: pointer;
		background: #fff;
		position: relative;
	}
	
	.tuijian .container .tuijianBody .productCarousel ul li .one-second {
		background: red;
		color: #fff;
		width: 64px;
		height: 20px;
		line-height: 20px;
		position: absolute;
		top: 0px;
		left: 85px;
		font-size: 14px;
	}
	
	.tuijian .container .tuijianBody .productCarousel ul li .img {
		width: 160px;
		height: 166px;
		margin: 0px auto 22px;
	}
	
	.tuijian .container .tuijianBody .productCarousel ul li .img img {
		width: 100%;
	}
	
	.tuijian .container .tuijianBody .productCarousel ul li .title {
		width: 194px;
		height: 40px;
		margin: 0 auto 3px;
		font-size: 14px;
		font-weight: 400;
		text-overflow: ellipsis;
	}
	
	.tuijian .container .tuijianBody .productCarousel ul li .title a {
		color: #212121;
		text-overflow: ellipsis;
	}
	
	.tuijian .container .tuijianBody .productCarousel ul li .subTitle {
		width: 194px;
		height: 18px;
		margin: 0 auto 12px;
		font-size: 12px;
		text-overflow: ellipsis;
	}
	
	.tuijian .container .tuijianBody .productCarousel ul li .subTitle a {
		color: #b0b0b0;
	}
	
	.tuijian .container .tuijianBody .productCarousel ul li .price a {
		color: #ff6709;
	}
	
	.tuijian .container .tuijianBody .productCarousel ul li .price a span {
		color: #b0b0b0;
		text-decoration: line-through;
	}
	/*------------------end tuijian--------*/
	/*------------------start reping--------*/
	
	.reping {
		height: 500px;
	}
	
	.reping .container {
		height: 473px;
		/*border:1px solid red;*/
		font-size: 15px;
		margin-bottom: 22px;
	}
	
	.reping .container .title {
		height: 58px;
		line-height: 58px;
		position: relative;
	}
	
	.reping .container .title h2 {
		font-size: 22px;
		font-weight: 200;
		text-overflow: ellipsis;
	}
	
	.reping .container .repingBody {
		height: 415px;
		display: flex;
	}
	
	.reping .container .repingBody .productCarousel {
		overflow: hidden;
	}
	
	.reping .container .repingBody .productCarousel ul {
		display: flex;
		flex-wrap: nowrap;
	}
	
	.reping .container .repingBody .productCarousel ul li {
		height: 415px;
		margin: 0 0 14px 14px;
		width: 296px;
		text-align: center;
		cursor: pointer;
		background: #fff;
		position: relative;
	}
	
	.reping .container .repingBody .productCarousel ul li:first-child {
		margin: 0 0 14px;
	}
	
	.reping .container .repingBody .productCarousel ul li .one-second {
		background: red;
		color: #fff;
		width: 64px;
		height: 20px;
		line-height: 20px;
		position: absolute;
		top: 0px;
		left: 85px;
		font-size: 14px;
	}
	
	.reping .container .repingBody .productCarousel ul li .img {
		width: 296px;
		height: 220px;
		margin: 0px auto 28px;
	}
	
	.reping .container .repingBody .productCarousel ul li .img img {
		width: 100%;
	}
	
	.reping .container .repingBody .productCarousel ul li .title {
		width: 240px;
		height: 72px;
		margin: 0 auto 22px;
		font-size: 14px;
		font-weight: 400;
		text-overflow: ellipsis;
	}
	
	.reping .container .repingBody .productCarousel ul li .title a {
		color: #212121;
		display: block;
		width: 240px;
		height: 72px;
		line-height: 24px;
	}
	
	.reping .container .repingBody .productCarousel ul li .subTitle {
		width: 230px;
		height: 18px;
		margin: 0 auto 8px;
		font-size: 12px;
		text-align: left;
	}
	
	.reping .container .repingBody .productCarousel ul li .subTitle a {
		color: #b0b0b0;
	}
	
	.reping .container .repingBody .productCarousel ul li .price {
		text-align: left;
		width: 236px;
		height: 22px;
		margin: 0 auto;
	}
	
	.reping .container .repingBody .productCarousel ul li .price a {
		color: #ff6709;
	}
	
	.reping .container .repingBody .productCarousel ul li .price a span {
		color: #333;
	}
	/*------------------end reping--------*/
	/*------------------start top---------*/
	
	.right-bar {
		position: fixed;
		bottom: 70px;
		right: 0;
		z-index: 999999;
		/*border:1px solid red;*/
	}
	
	@media only screen and (min-width:1456px) {
		.right-bar .bar-sm {
			display: none;
		}
		.right-bar .bar-lg .bar-top ul li {
			position: relative;
			display: block;
			width: 82px;
			height: 90px;
			list-style: none;
			background-color: #fff;
			border: 1px solid #f5f5f5;
			border-top: none;
		}
		.right-bar .bar-lg .bar-top ul li:before {
			content: "";
			display: table;
		}
		.right-bar .bar-lg .bar-top ul li a .bar-img {
			width: 30px;
			height: 30px;
			margin-left: 30px;
			margin-top: 30px;
			transition: all .3s;
		}
		.right-bar .bar-lg .bar-top ul li:first-child a .bar-img {
			background: url(../../static/img/right-1.png) round;
		}
		.right-bar .bar-lg .bar-top ul li:nth-child(2) a .bar-img {
			background: url(../../static/img/right-2.png) round;
		}
		.right-bar .bar-lg .bar-top ul li:last-child a .bar-img {
			background: url(../../static/img/right-3.png) round;
		}
		.right-bar .bar-lg .bar-top ul li:first-child:hover a .bar-img {
			background: url(../../static/img/right-1-hover.png) round;
		}
		.right-bar .bar-lg .bar-top ul li:nth-child(2):hover a .bar-img {
			background: url(../../static/img/right-2-hover.png) round;
		}
		.right-bar .bar-lg .bar-top ul li:last-child:hover a .bar-img {
			background: url(../../static/img/right-3-hover.png) round;
		}
		.right-bar .bar-lg .bar-top ul li a p {
			margin: 8px 0 0 0;
			color: #757575;
			font-size: 14px;
			text-align: center;
			transition: all .3s;
		}
		.right-bar .bar-lg .bar-top ul li:hover a p {
			color: #FF6700;
		}
		.right-bar .bar-lg .totop {
			position: relative;
			display: block;
			width: 82px;
			height: 90px;
			list-style: none;
			background-color: #fff;
			border: 1px solid #f5f5f5;
			margin-top: 20px;
		}
		.right-bar .bar-lg .totop .totop-img {
			width: 30px;
			height: 30px;
			margin-left: 30px;
			margin-top: 30px;
			transition: all .3s;
			background: url(../../static/img/totop.png) round;
		}
		.right-bar .bar-lg .totop:hover .totop-img {
			background: url(../../static/img/totop_hover.png) round;
		}
		.right-bar .bar-lg .totop p {
			margin: 8px 0 0 0;
			color: #757575;
			font-size: 14px;
			text-align: center;
			transition: all .3s;
		}
		.right-bar .bar-lg .totop:hover p {
			color: #FF6700;
		}
	}
	
	@media only screen and (max-width:1455px) {
		.right-bar .bar-lg {
			display: none;
		}
		.right-bar .bar-sm {
			display: block;
			height: 176px;
			width: 27px;
			position: fixed;
			right: 0px;
			bottom: 0px;
		}
		.right-bar .bar-sm ul li {
			position: relative;
			display: block;
			list-style: none;
			background-color: #fff;
			border: 1px solid #f5f5f5;
			border-top: none;
		}
		.right-bar .bar-sm ul li:last-child {
			margin-top: 15px;
		}
		.right-bar .bar-sm ul li a img {
			width: 100%;
			transition: all .3s;
		}
		.right-bar .bar-sm ul li a img:last-child {
			display: none;
		}
		.right-bar .bar-sm ul li:hover a img:last-child {
			display: block;
		}
		.right-bar .bar-sm ul li:hover a img:first-child {
			display: none;
		}
	}
	/*------------end totop-------------*/
</style>