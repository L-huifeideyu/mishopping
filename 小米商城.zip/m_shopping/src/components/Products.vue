<template>
	<div>
		<Header></Header>
		<div class="products w clear">
			<h3>小米手机</h3>
			<div class="product_list clear">
				<ul>
					<li v-for="(item,index) in plist.products">
						<div class="p_img">
							<router-link :to="`/detail/${item.lid}`"><img :src="item.img" /></router-link>
						</div>
						<p class="title">
							<router-link to="`/detail/${item.lid}`" class="a">{{item.title}}</router-link>
						</p>
						<p class="subtitle">{{item.subtitle}}</p>
						<p class="price">{{item.price}}元</p>
					</li>
				</ul>

			</div>
			<div class="page clear">
				<ul class="clear ">
					<li><button class="prev" @click="prevOrNext(-1)">上一页</button></li>
					<li v-for="num in pageCount"><button :class="{pno:true,active:active == num}" @click="onChangePage(num)">{{num}}</button></li>	
					<li><button class="next" @click="prevOrNext(+1)">下一页</button></li>
				</ul>

			</div>
		</div>
		<Footer></Footer>
	</div>
</template>

<script>
	import Header from './Header'
	import Footer from './Footer'
	export default {
		components: {
			Header,
			Footer
		},
		data: function() {
			return {
				plist: [],
				fid: '',
				pno: 0,
				pageCount:0,
				active:1
				
			}
		},
		methods: {
			getProducts() {
				this.fid = this.$route.params.search
				this.axios.get('/products', {
						params: {
							fid: this.fid,
							pno: this.pno
						}
					})
					.then(res => {
						this.plist = res.data;
						this.pageCount = this.plist.pageCount
						//console.log(this.plist)
					})
			},
			onChangePage(i){
				this.pno = i-1
				this.active = i
				this.getProducts();
			},
			prevOrNext(t){
				if(t == -1&&this.pno>0){
					this.pno--
					this.active--
					this.getProducts();
				}else if(t == +1&&this.pno<this.pageCount-1){
					this.pno++
					this.active++
					this.getProducts();
				}
			}
		},
		mounted() {
			this.getProducts();
		}
	}
</script>

<style scoped>
	.products>h3 {
		margin-top: 20px;
		height: 58px;
		line-height: 58px;
		font-size: 22px;
		font-weight: bold;
	}
	
	.product_list>ul li {
		width: 226px;
		height: 339px;
		margin: 0 14px 20px 0;
		cursor: pointer;
		background: rgba(250, 250, 250);
		float: left;
		border: 2px solid #fff
	}
	
	.product_list>ul li:hover {
		border: 2px solid #FF6709;
	}
	
	.product_list>ul li .p_img {
		width: 156px;
		height: 160px;
		padding: 37px;
	}
	
	.product_list>ul li .p_img img {
		width: 100%;
	}
	
	.product_list>ul li p.title {
		width: 234px;
		height: 14px;
		line-height: 14px;
		text-align: center;
		margin-top: -10px;
		font-size: 14px;
	}
	
	.product_list>ul li p.title .a {
		display: block;
		width: 234px;
		height: 14px;
		line-height: 14px;
	}
	
	.product_list>ul li p.subtitle {
		width: 234px;
		height: 12px;
		line-height: 12px;
		font-size: 12px;
		margin: 15px 0;
		color: rgba(176, 176, 176);
		text-align: center;
	}
	
	.product_list>ul li p.price {
		width: 234px;
		height: 19px;
		line-height: 19px;
		font-size: 14px;
		color: #FF6709;
		text-align: center;
	}
	
	.products .page {
		height: 58px;
		line-height: 58px;
		background: rgba(250, 250, 250);
	}
	
	.products .page>ul {
		display: inline-block;
		margin: 0 auto;
		float: right;
	}
	
	.products .page>ul li {
		float: left;
	}
	
	.products .page>ul li button {
		background: #fff;
		border: 1px solid #eee;
		height: 30px;
		padding: 0 5px;
		cursor: pointer;
		outline: none;
		font-size: 16px;
	}
	
	.products .page>ul li button:hover {
		border-color: #FF6709;
	}
	
	.products .page>ul li button.active {
		border-color: #FF6709;
	}
	
	.products .page>ul li button.pno {
		width: 30px;
	}
</style>