<template>
	<div>
		<footer class="clear">
			<div class="sub-footer w">
				<div class="service">
					<ul>
						<li>
							<a href="#"><img src="../../static/img/footer_0000.png" />预约维修服务</a>
						</li>
						<li>
							<a href="#"><img src="../../static/img/footer_0001.png" />7天无理由退货</a>
						</li>
						<li>
							<a href="#"><img src="../../static/img/footer_0002.png" />15天免费换货</a>
						</li>
						<li>
							<a href="#"><img src="../../static/img/footer_0003.png" />满150元包邮</a>
						</li>
						<li>
							<a href="#"><img src="../../static/img/footer_0004.png" />500余家售后网点</a>
						</li>
					</ul>
				</div>
				<div class="links clear">
					<dl>
						<dt>帮助中心</dt>
						<dd>
							<a href="#">账户管理</a>
						</dd>
						<dd>
							<a href="#">购物指南</a>
						</dd>
						<dd>
							<a href="#">订单操作</a>
						</dd>
					</dl>
					<dl>
						<dt>服务支持</dt>
						<dd>
							<a href="#">售后政策</a>
						</dd>
						<dd>
							<a href="#">自助服务</a>
						</dd>
						<dd>
							<a href="#">相关服务</a>
						</dd>
					</dl>
					<dl>
						<dt>线下门店</dt>
						<dd>
							<a href="#">小米之家</a>
						</dd>
						<dd>
							<a href="#">服务网点</a>
						</dd>
						<dd>
							<a href="#">授权体验店</a>
						</dd>
					</dl>
					<dl>
						<dt>关于小米</dt>
						<dd>
							<a href="#">了解小米</a>
						</dd>
						<dd>
							<a href="#">加入小米</a>
						</dd>
						<dd>
							<a href="#">投资者关系</a>
						</dd>
					</dl>
					<dl>
						<dt>关注我们</dt>
						<dd>
							<a href="#">新浪微博</a>
						</dd>
						<dd>
							<a href="#">官方微信</a>
						</dd>
						<dd>
							<a href="#">联系我们</a>
						</dd>
					</dl>
					<dl>
						<dt>特色服务</dt>
						<dd>
							<a href="#">F码通道</a>
						</dd>
						<dd>
							<a href="#">礼物码</a>
						</dd>
						<dd>
							<a href="#">防伪查询</a>
						</dd>
					</dl>
					<div class="contact clear">
						<p>400-100-6789</p>
						<p>周一至周日8:00-18:00<br />(仅收市话费)</p>
						<a href="#" class="btn btn-small btn-line-primary">联系客服</a>
					</div>
				</div>
			</div>
			<div class="main-footer">
				<div class="container w">
					<div class="logo">

					</div>
					<div class="info-text">
						<ul>
							<li>
								<a href="index.html">小米商城</a>
							</li>
							<li>
								|
							</li>
							<li>
								<a href="#">MIUI</a>
							</li>
							<li>
								|
							</li>
							<li>
								<a href="#">米家</a>
							</li>
							<li>
								|
							</li>
							<li>
								<a href="#">米聊</a>
							</li>
							<li>
								|
							</li>
							<li>
								<a href="#">多看</a>
							</li>
							<li>
								|
							</li>
							<li>
								<a href="#">游戏</a>
							</li>
							<li>
								|
							</li>
							<li>
								<a href="#">路由器</a>
							</li>
							<li>
								|
							</li>
							<li>
								<a href="#">米粉卡</a>
							</li>
							<li>
								|
							</li>
							<li>
								<a href="#">政企服务</a>
							</li>
							<li>
								|
							</li>
							<li>
								<a href="#">小米天猫店</a>
							</li>
							<li>
								|
							</li>
							<li>
								<a href="#">隐私政策</a>
							</li>
							<li>
								|
							</li>
							<li>
								<a href="#">问题反馈</a>
							</li>
							<li>
								|
							</li>
							<li>
								<a href="#">廉政举报</a>
							</li>
							<li>
								|
							</li>
							<li>
								<a href="#">Select Region</a>
							</li>
						</ul>
						<p class="clear">© &nbsp;&nbsp;mi.com &nbsp;&nbsp;京ICP证110507号 &nbsp;&nbsp; 京ICP备10046444号&nbsp;&nbsp; 京公网安备11010802020134号 &nbsp;&nbsp; 京网文[2017]1530-131号 <br> （京）网械平台备字（2018）第00005号&nbsp;&nbsp; 互联网药品信息服务资格证 (京) -非经营性-2014-0090&nbsp;&nbsp; 营业执照&nbsp;&nbsp;
							<br>违法和不良信息举报电话：185-0130-1238，本网站所列数据，除特殊说明，所有数据均出自我司实验室测试</p>
					</div>
					<div class="info-links">
						<a href="#"><img src="../../static/img/footer-truste.png" alt="" /></a>
						<a href="#"><img src="../../static/img/footer-v-logo-1.png" alt="" /></a>
						<a href="#"><img src="../../static/img/footer-v-logo-2.png" alt="" /></a>
						<a href="#"><img src="../../static/img/footer-v-logo-3.png" alt="" /></a>
						<a href="#"><img src="../../static/img/footer-last.png" alt="" /></a>
					</div>
					<div class="slogan clear"></div>
				</div>

			</div>

		</footer>
	</div>
</template>

<script>
	export default{
		
	}
</script>

<style scoped>
	
/*------------------start  footer------------*/
footer .sub-footer{
	height: 272px;
	color: #333;
}
footer .sub-footer .service{
	padding: 27px 0;
	height: 25px;
	border-bottom:1px solid #e0e0e0;
}
footer .sub-footer .service ul li{
	float: left;
	width: 19.8%;
	height:25px;
	line-height: 25px;
	text-align: center;
	border-left: 1px solid #e0e0e0;
	font-size: 16px;
}
footer .sub-footer .service ul li img{
	height: 25px;
	vertical-align:top;
}
footer .sub-footer .service ul li a{
	color: #616161;
}
footer .sub-footer .service ul li:first-child{
	border-left: 0;
}
footer .links {
	height: 112px;
	padding: 40px 0;
	color: #333333;
}
footer .links dl{
	float: left;
	width: 160px;
	height:112px;
}
footer .links dl dt{
	height: 17px;
	margin:-1px 0 26px;
	font-size:14px;
	color: #424242;
}
footer .links dl dd{
	margin-top: 10px;
	height: 18px;
	font-size:12px;
}
footer .links dl dd a{
	color: #757575;
	transition:all .3s;
}
footer .links dl dd a:hover{
	color:#FF6700
}
footer .links .contact{
	float: right;
    width: 251px;
    height: 112px;
    border-left: 1px solid #e0e0e0;
    text-align: center;
    color: #616161;
}
footer .links .contact p:first-of-type{
	margin: 0 0 5px;
    font-size: 22px;
    line-height: 1;
    color: #ff6700;
}
footer .links .contact p:last-of-type{
	 margin: 0 0 16px;
    font-size: 12px;
}
footer .links .contact a:last-child:hover{
	background: #FF6700;	
	color: #fff;
}
footer .main-footer{
	padding: 30px 0;
    font-size: 12px;
    background: #fafafa;
    height: 122px;
    position: relative;
}
footer .main-footer .logo{
	float: left;
	height: 57px;
	width: 57px;
	margin-right: 10px;
	background: url('../../static/img/logo_foot.png');
}
footer .main-footer .info-text{
	line-height: 18px;
}
footer .main-footer .info-text ul li{
	float: left;
	color: #b0b0b0;
	font-size:12px ;
	line-height: 18px;
}
footer .main-footer .info-text ul li a{
	color: #757575;
	font-size: 12px;
	display: block;
	padding: 0 3px;
}
footer .main-footer .info-text p{
	float: left;
	color: #b0b0b0;
}
footer .main-footer .info-links img{
	width: auto;
	height: 28px;
	float: right;
}
footer .main-footer .slogan{
    margin: 30px auto 0;
    width: 267px;
    height: 19px;
    position: absolute;
    bottom: 30px;
    left: 50%;
    background: url('../../static/img/slogan2016.png') no-repeat center 0;
}
/*------------------end  footer------------*/
</style>