<template>
	<div>
		<Header></Header>
		<div class="grzxbj">
			<div class="selfinfo center">
				<div class="lfnav fl">
					<div class="ddzx">订单中心</div>
					<div class="subddzx">
						<ul>
							<li>
								<a href="#" @click.prev="onOrderCenter">我的订单</a>
							</li>
							<li>
								<a href="">意外保</a>
							</li>
							<li>
								<a href="">团购订单</a>
							</li>
							<li>
								<a href="">评价晒单</a>
							</li>
						</ul>
					</div>
					<div class="ddzx">个人中心</div>
					<div class="subddzx">
						<ul>
							<li>
								<a href="./self_info.html" style="color:#ff6700;font-weight:bold;">我的个人中心</a>
							</li>
							<li>
								<a href="">消息通知</a>
							</li>
							<li>
								<a href="">优惠券</a>
							</li>
							<li>
								<a href="">收货地址</a>
							</li>
						</ul>
					</div>
				</div>
				<div class="rtcont fr">
					<div class="grzlbt ">我的资料</div>
					<div class="subgrzl "><span>昵称</span><input type="text" name="uname" id="uname" v-model='uname'/></div>
					<div class="subgrzl "><span>手机号</span><input type="text" name="phone" id="phone" v-model="phone" /></div>
					<div class="subgrzl "><span>邮箱</span><input type="text" name="email" id="email" v-model="email" /></div>
					<div class="subgrzl "><span>个性签名</span><input type="text" name="autograph" id="autograph" v-model="autograph" /></div>
					<div class="subgrzl "><span>我的爱好</span><input type="text" name="hobby" id="hobby" v-model="hobby"/></div>
					<div class="subgrzl "><span>收货地址</span><input type="text" name="adress" id="adress" v-model="adress" /></div>
					<div class="submit">
						<button @click="postInfo">提交</button>
					</div>
				</div>
				<div class="clear"></div>
			</div>
		</div>
		<Footer></Footer>
	</div>

</template>

<script>
	import Header from './Header'
	import Footer from './Footer'
	import Qs from 'qs'
	export default {
		components: {
			Header,
			Footer
		},
		data: function() {
			return {
				uid: '',
				ulist:[],
				uname:'',
				phone:'',
				email:'',
				autograph:'',
				hobby:'',
				adress:''
			}
		},
		methods: {
			onOrderCenter() {
				this.uid = this.$route.params.uid
				this.$router.push('/order_center/' + this.uid)
			},
			selectSelfInfo() {
				this.uid = this.$route.params.uid
				this.axios.post('/user/selectSelfInfo', Qs.stringify({
						uid: this.uid
					}))
					.then(res => {
						this.ulist = res.data
						//console.log(this.ulist)
						this.uname = this.ulist.uname;
						this.phone = this.ulist.phone;
						this.email = this.ulist.email;
						this.autograph = this.ulist.autograph;
						this.hobby = this.ulist.hobby;
						this.adress = this.ulist.adress;
					})
			},
			postInfo(){
				this.axios.post('/user/update',Qs.stringify({
					uid:this.uid,
					uname:this.uname,
					email:this.email,
					autograph:this.autograph,
					hobby:this.hobby,
					adress:this.adress,
					phone:this.phone
				})).then(res=>{
					if(res.data.state == 'ok')
					{
						alert('修改成功')
					}
				})
			}
		},
		mounted() {
			this.selectSelfInfo();
		}
	}
</script>

<style scoped>
	.grzxbj {
		width: 100%;
		height: auto;
		background: rgb(245, 245, 245);
		padding-bottom: 20px;
		padding-top: 20px;
	}
	
	.grzxbj .selfinfo {
		width: 1226px;
	}
	
	.grzxbj .selfinfo .lfnav {
		width: 234px;
		height: 500px;
		background: #fff;
	}
	
	.grzxbj .selfinfo .lfnav .ddzx {
		width: 234px;
		height: 40px;
		line-height: 40px;
		font-size: 19px;
		margin: 30px 20px 10px 40px;
		color: rgb(51, 51, 51);
	}
	
	.grzxbj .selfinfo .lfnav .subddzx ul li {
		display: block;
		width: 194px;
		height: 40px;
		line-height: 40px;
		padding-left: 40px;
	}
	
	.grzxbj .selfinfo .lfnav .subddzx ul li a {
		color: rgb(117, 117, 117);
	}
	
	.grzxbj .selfinfo .lfnav .subddzx ul li a:hover {
		color: rgb(51, 51, 51);
	}
	
	.grzxbj .selfinfo .rtcont {
		width: 978px;
		height: 500px;
		background: #fff;
	}
	
	.grzxbj .selfinfo .rtcont .ddzxbt {
		width: 938px;
		height: 60px;
		line-height: 60px;
		font-size: 22px;
		font-weight: bold;
		color: rgb(117, 117, 117);
		padding-left: 40px;
		border-bottom: 1px solid #ccc;
	}
	
	.grzxbj .selfinfo .rtcont .grzlbt {
		width: 938px;
		height: 60px;
		line-height: 60px;
		font-size: 20px;
		color: rgb(117, 117, 117);
	}
	
	.grzxbj .selfinfo .rtcont .subgrzl {
		height: 45px;
		line-height: 45px;
		width: 900px;
		background: rgb(253, 253, 253);
		border: 1px solid #aaa;
		margin-top: 10px;
		margin-bottom: 10px;
		border-radius: 3px;
		margin-left: 40px;
	}
	
	.grzxbj .selfinfo .rtcont .subgrzl span:nth-of-type(1) {
		display: inline-block;
		font-size: 15px;
		font-weight: bold;
		color: rgb(117, 117, 117);
		width: 70px;
		height: 45px;
		line-height: 45px;
		padding-left: 20px;
	}
	
	.grzxbj .selfinfo .rtcont .subgrzl input:nth-child(2) {
		display: inline-block;
		font-size: 15px;
		color: rgb(117, 117, 117);
		width: 480px;
		height: 43px;
		line-height: 43px;
		padding-left: 120px;
		border:0;
		outline: none;
	}
	
	
	
	.grzxbj .selfinfo .rtcont .subgrzl span a {
		color: teal;
	}
	
	.grzxbj .selfinfo .rtcont .subgrzl span a:hover {
		color: #ff6700;
	}
	
	.grzxbj .selfinfo .rtcont .submit button {
		display: block;
		height: 45px;
		line-height: 45px;
		width: 160px;
		text-align: center;
		margin: 0 auto;
		cursor: pointer;
		background: #FF6700;
		border: 0;
		font-size: 20px;
		color: #fff;
		outline: none;
	}
</style>