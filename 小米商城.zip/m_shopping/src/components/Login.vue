<template>
	<div>
		<div class="top">
			<div class="container w">
				<div class="logo_img">
					<a href="/index"></a>
				</div>
			</div>
		</div>
		<div class="login_banner">

		</div>
		<div class="wrap">
			<div class="layout_panel">
				<div class="layout">
					<div class="nav_tab_panel">
						<div class="nav_tabs">
							<a href="#" :class="{now:howLogin.zhanghao==1}" @click.prevent="how(1)">账号登陆</a>
							<span></span>
							<a href="#" :class="{now:howLogin.duanxin==1}" @click.prevent="how(2)">短信登陆</a>
						</div>

					</div>
					<div :class="{now:howLogin.zhanghao==1,form:true}">
						<div class="uname">
							<input type="text" name="uname" id="uname" placeholder="邮箱/手机号码/小米ID" autofocus v-model="uname" required/>
						</div>
						<div class="upwd">
							<input type="password" name="upwd" id="upwd" placeholder="密码" required v-model="upwd" />
						</div>
						<div class="yanzhengma">
							<input type="text" name="yanzhengma" id="yanzhengma" placeholder="验证码" required v-model="checkCode" @keyup.13="login1" />
							<span @click="yanzheng()">{{code}}</span>
						</div>
						<span>{{isSuccess}}</span>
						<div class="submit">
							<input type="submit" id="login" value="登  陆" @click="login1" />
						</div>
						<div class="login_type">
							<span class="fl"><router-link to="/register">手机短信登陆/注册</router-link></span>
							<span class="fr"><router-link to="/register">立即注册</router-link>&nbsp;|&nbsp;<a href="javascript:void(0);">忘记密码？</a></span>
						</div>
						<div class="bottom">

						</div>
					</div>
					<div :class="{now:howLogin.duanxin==1,form:true,phoneLogin:true}">
						<div class="phone">
							<input type="text" name="phone" id="phone" placeholder="请输入手机号码" autofocus required v-model='phone' />
						</div>

						<div class="yPhone">
							<input type="text" name="yPhone" id="yPhone" placeholder="验证码" required v-model="checkPhoneCode" @keyup.13="login2"/>
							<span :class="{toCode:true,send:sendClass}" @click="oncheckPhone">{{sendCode}}</span>
						</div>
						<span>{{isphone}}</span>
						<div class="submit">
							<input type="submit" id="login" value="登  陆" @click="login2" />
						</div>
						<div class="login_type">
							<span class="fl"><router-link to="/register">手机短信登陆/注册</router-link></span>
							<span class="fr"><router-link to="/register">立即注册</router-link>&nbsp;|&nbsp;<a href="javascript:void(0);">忘记密码？</a></span>
						</div>
						<div class="bottom">

						</div>
					</div>
				</div>
			</div>
		</div>
		<Footer></Footer>
	</div>
</template>

<script>
	import Footer from './Footer'
	import https from 'https'
	import Qs from 'qs'
	export default {
		components: {
			Footer
		},
		data: function() {
			return {
				uname: "",
				upwd: "",
				isSuccess: "",
				topath: "",
				code: "",
				checkCode: '',
				codeLength: 6,
				codeArr: [],
				howLogin: {
					zhanghao: 1,
					duanxin: 0
				},
				isphone: '',
				phoneReg: /^((\+86|0086)?\s*1[3-8]\d{9})$/,
				phone: '',
				time: 60,
				sendCode: '发送验证码',
				sendClass: false,
				c: '',
				checkPhoneCode: '',
				num: 1

			}
		},
		created() {
			//console.log(this.$route)
			this.yanzhengshuaxin();

		},
		methods: {
			how(i) {
				if(i == 1) {
					this.howLogin.zhanghao = 1;
					this.howLogin.duanxin = 0;
				}
				else {
					this.howLogin.zhanghao = 0;
					this.howLogin.duanxin = 1;
				}
			},
			login1() {
				this.axios.post("/user/login", Qs.stringify({
						user_name: this.uname,
						upwd: this.upwd
					}))
					.then(res => {
						if(res.data.state == 'ok' && this.checkCode == this.code.toLowerCase()) {

							this.topath = this.$route.params.back;
							//console.log(this.$route.params.back)
							if(this.topath == 'register') {
								this.topath = '/index'
								alert("登陆成功，即将跳转到主页！")
								this.$router.push(this.topath)
							}
							else {
								alert("登陆成功，即将跳回您来时的页面！")
								this.$router.push('/' + this.topath)
							}

						}
						else if(this.checkCode != this.code.toLowerCase()) {
							this.isSuccess = '验证码错误！'
						}
						else {
							this.isSuccess = '用户名或密码错误！'
						}
					})
			},
			login2() {

				if(this.checkPhoneCode == this.c) {
					this.isphone = ''
					this.axios.post('/user/phoneLogin', Qs.stringify({
							phone: this.phone
						}))
						.then(res => {
							if(res.data.state == 'ok') {
								this.topath = this.$route.params.back;
								//console.log(this.$route.params.back)
								if(this.topath == 'register') {
									this.topath = '/index'
									alert("登陆成功，即将跳转到主页！")
									this.$router.push(this.topath)
								}
								else {
									alert("登陆成功，即将跳回您来时的页面！")
									this.$router.push('/' + this.topath)
								}
							}
						})
				}
				else {
					this.isphone = '验证码错误！'
				}
			},
			yanzheng() {
				this.codeArr = new Array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9,
					'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
					'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');
				var str = ''
				for(var i = 0; i < this.codeLength; i++) {
					var charNum = Math.floor(Math.random() * 52);
					str += this.codeArr[charNum];
				}
				this.code = str
				//console.log(this.code)
			},
			yanzhengshuaxin() {
				this.yanzheng()
				setInterval(this.yanzheng, 50000)
			},
			oncheckPhone() {
				if(!this.phoneReg.test(this.phone)) {
					this.isphone = '手机号格式不正确！'
				}
				else {
					this.axios.post('/user/selectphone', Qs.stringify({
							phone: this.phone
						}))
						.then(res => {
							if(res.data.state == 'no') {
								this.isphone = '手机号尚未注册，请先注册！'
							}
							else {
								this.sendClass = true;

								this.num++;
								if(this.num == 3) {
									this.isphone = '每小时只允许输入三次';
								}
								else {
									this.sendCodePhone();
									this.timer()
									this.isphone = '';
								}

							}
						})
				}

			},
			timer() {
				var timer = setInterval(() => {
					this.time--
						this.sendCode = `(${this.time}s)后重新发送`;
					if(this.time <= 0) {
						clearInterval(timer);
						this.time = 60;
						this.sendClass = false;
						this.sendCode = '发送验证码'
					}
				}, 1000)

			},
			productCode() {
				var codeArr = [];
				for(var i = 0; i < 6; i++) {
					codeArr.push(Math.ceil(Math.random() * 9))
				}
				this.c = codeArr.join('');

			},

			sendCodePhone() {
				var apikey = '7b63f8dbf59db01d372c791637ffa6ac';
				var mobile = this.phone;

				//this.c = productCode();
				this.productCode();
				setInterval(this.productCode, 60000)

				var text = `【米商城】您的验证码是${this.c}。如非本人操作，请忽略本短信`;

				//console.log(text)
				var sms_host = 'sms.yunpian.com'; //请求地址的url
				var send_sms_uri = '/v2/sms/single_send.json'; //请求地址的url
				var post_data = {
					'apikey': apikey,
					'mobile': mobile,
					'text': text,
				};
				var content = Qs.stringify(post_data);
				post(send_sms_uri, content, sms_host);

				function post(uri, content, host) {
					var options = {
						hostname: host,
						port: 443,
						path: uri,
						method: 'POST',
						headers: {
							'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
							
						}
					};

					var req = https.request(options, function(res) {
						res.setEncoding('utf8');
						res.on('data', function(chunk) {
							console.log('BODY: ' + chunk + code);
						});
					});
					req.write(content);
					req.end();

				}
			}
		},
		mounted() {

		}
	}
</script>

<style scoped>
	/*---------------start top------------------------*/
	
	.top .logo_img {
		width: 200px;
		height: 98px;
		background: url(../../static/img/mistore_logo.png) no-repeat;
		position: relative;
		z-index: 999;
	}
	
	.top .logo_img a {
		display: block;
		width: 200px;
		height: 98px;
	}
	/*---------------end top------------------------*/
	/*---------------start login_banner------------------------*/
	
	.login_banner {
		width: 100%;
		height: 588px;
		background: url(../../static/img/login_bg_new.jpg) top center;
	}
	
	.wrap {
		position: absolute;
		top: 0;
		height: 654px;
		width: 100%;
		/*background: #B0B0B0;*/
	}
	
	.wrap .layout_panel {
		width: 1130px;
		height: 524px;
		padding-top: 130px;
		margin: 0 auto;
		/*background: #30B0B0;*/
	}
	
	.wrap .layout_panel .layout {
		width: 410px;
		height: 524px;
		font-size: 14px;
		background: #fff;
		margin: 0 auto 20px;
		margin-right: 0px;
		margin-bottom: 0px;
		position: relative;
	}
	
	.wrap .layout_panel .layout .nav_tab_panel .nav_tabs {
		padding: 27px 0 24px;
		text-align: center;
		width: 410px;
		height: 31px;
		display: flex;
		flex-flow: nowrap;
		justify-content: center;
	}
	
	.wrap .layout_panel .layout .nav_tab_panel .nav_tabs span {
		display: inline-block;
		width: 0px;
		height: 31px;
		border: 1px solid #b0b0b0;
		margin: 0 40px;
	}
	
	.wrap .layout_panel .layout .nav_tab_panel .nav_tabs a {
		display: inline-block;
		font-size: 24px;
		color: #666;
	}
	
	.wrap .layout_panel .layout .nav_tab_panel .nav_tabs .now {
		color: #FF6700;
	}
	
	.wrap .layout_panel .layout .form.now {
		display: block;
	}
	
	.wrap .layout_panel .layout .form {
		display: none;
	}
	
	.wrap .layout_panel .layout .form>span {
		color: #FF6700;
		margin-left: 31px;
	}
	
	.wrap .layout_panel .layout .form input {
		width: 316px;
		height: 22px;
		padding: 13px 16px 13px 14px;
		border: 0px;
		outline: none;
	}
	
	.wrap .layout_panel .layout .form .uname,
	.wrap .layout_panel .layout .form .upwd {
		border: 1px solid #e0e0e0;
		width: 346px;
		height: 48px;
		margin: 0px auto;
		margin-bottom: 14px;
	}
	
	.wrap .layout_panel .layout .phoneLogin .phone {
		border: 1px solid #e0e0e0;
		width: 346px;
		height: 48px;
		margin: 0px auto;
		margin-bottom: 14px;
	}
	
	.wrap .layout_panel .layout .phoneLogin .yPhone {
		width: 346px;
		height: 48px;
		margin-left: 31px;
		margin-bottom: 14px;
		position: relative;
	}
	
	.wrap .layout_panel .layout .phoneLogin .yPhone input {
		width: 150px;
		height: 22px;
		padding: 13px 16px 13px 14px;
		border: 0px;
		outline: none;
		float: left;
		border: 1px solid #e0e0e0;
	}
	
	.wrap .layout_panel .layout .phoneLogin .yPhone .toCode {
		display: block;
		height: 48px;
		line-height: 48px;
		border: 1px solid #e0e0e0;
		width: 130px;
		position: absolute;
		right: 0px;
		background: #FF6700;
		text-align: center;
		font-size: 14px;
		letter-spacing: 2px;
		color: #fff;
		cursor: pointer;
		user-select: none;
	}
	
	.wrap .layout_panel .layout .phoneLogin .yPhone .toCode.send {
		background: #999999;
	}
	
	.wrap .layout_panel .layout .form .yanzhengma {
		/*border: 1px solid #e0e0e0;*/
		width: 346px;
		height: 48px;
		margin-left: 31px;
		margin-bottom: 14px;
		position: relative;
	}
	
	.wrap .layout_panel .layout .form .yanzhengma input {
		width: 150px;
		height: 22px;
		padding: 13px 16px 13px 14px;
		border: 0px;
		outline: none;
		float: left;
		border: 1px solid #e0e0e0;
	}
	
	.wrap .layout_panel .layout .form .yanzhengma span {
		display: block;
		height: 48px;
		line-height: 48px;
		border: 1px solid #e0e0e0;
		width: 130px;
		position: absolute;
		right: 0px;
		background: url(../../static/img/yanzheng.jpg) round;
		text-align: center;
		font-size: 30px;
		letter-spacing: 2px;
		font-weight: bold;
		color: rgba(2, 49, 254);
		font-style: italic;
		cursor: pointer;
		user-select: none;
	}
	
	.wrap .layout_panel .layout .form .submit {
		width: 348px;
		height: 50px;
		padding-top: 10px;
		margin: 0 auto;
		margin-bottom: 14px;
	}
	
	.wrap .layout_panel .layout .form .submit input {
		width: 348px;
		height: 50px;
		color: #fff;
		background: #ef5b00;
		cursor: pointer;
	}
	
	.wrap .layout_panel .layout .form .login_type {
		width: 348px;
		margin: 0 auto;
	}
	
	.wrap .layout_panel .layout .form .login_type span:first-child a {
		color: #FF6700;
	}
	
	.wrap .layout_panel .layout .form .login_type span:last-child a {
		color: #b0b0b0;
	}
	
	.wrap .layout_panel .layout .form .login_type span:last-child a:hover {
		color: #FF6700;
	}
	
	.wrap .layout_panel .layout .form .bottom {
		width: 410px;
		height: 80px;
		position: absolute;
		bottom: 5px;
		background: url(../../static/img/2018-10-22_163105.png);
		cursor: pointer;
	}
	/*---------------end login_banner------------------------*/
	
	.footer {
		height: 300px;
		background: url(../../static/img/2018-10-22_163453.png) no-repeat center 40%;
	}
</style>