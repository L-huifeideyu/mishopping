import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/components/Home'
import Login from '@/components/Login'
import Register from '@/components/Register'
import Self_info from '@/components/Self_info'
import Order_center from '@/components/Order_center'
import Products from '@/components/Products'
import Shopping_cart from '@/components/Shopping_cart'
import Detail from '@/components/Detail'
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Home',
      redirect: '/index',
      meta:{
      	title:'小米商城 - 小米8、小米MIX 2S、红米6 Pro、小米电视官方网站'
      }
    },
    {
      path: '/index',
      name: 'Index',
      component: Home,
      meta:{
      	title:'小米商城 - 小米8、小米MIX 2S、红米6 Pro、小米电视官方网站'
      }
    },
    {
    	path:'/login/:back',
    	name:'Login',
    	component:Login,
    	meta:{
      	title:'小米商城 - 会员登陆'
      }
    },
    {
    	path:'/register',
    	name:'register',
    	component:Register,
    	meta:{
      	title:'小米商城 - 注册'
      }
    },
    {
    	path:'/self_info/:uid',
    	name:'self_info',
    	component:Self_info,
    	meta:{
      	title:'小米商城 - 个人中心'
      }
    },
    {
    	path:'/order_center/:uid',
    	name:'order_center',
    	component:Order_center,
    	meta:{
      	title:'小米商城 - 订单中心'
      }
    },
    {
    	path:'/products/:search',
    	name:'products',
    	component:Products,
    	meta:{
    		title:'小米商城 - 商品列表'
    	}
    },
    {
    	path:'/shopping_cart',
    	name:'shopping_cart',
    	component:Shopping_cart,
    	meta:{
    		title:'小米商城 - 购物车'
    	}
    },
    {
    	path:'/detail/:lid',
    	name:'Detail',
    	component:Detail,
    	meta:{
    		title:'小米商城 - 立即购买'
    	}
    }
  ]
})
